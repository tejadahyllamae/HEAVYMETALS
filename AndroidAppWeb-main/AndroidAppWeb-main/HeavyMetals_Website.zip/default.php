<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Heavy Metals</title>
    <link rel="stylesheet" href="HeavyMetals/admin_dashboard/heavymetals_styles.css">
</head>
<body>
    <!-- Header -->
    <header class="navbar">
        <div class="logo">
            <img src="HeavyMetals/admin_dashboard/icons/logo.png" alt="Heavy Metals Logo">
            <p>Heavy Metals</p>
        </div>
        
       
    </header>

    <!-- Hero Section -->
    <section class="hero">
        <div class="hero-content">
            <h1>Heavy Metals</h1>
            <p>Are you ready to transform your fitness journey
                Our app is your ultimate companion, designed to help you delve into 
                personalized workouts, track your progress, and stay motivated. With a user-friendly
                interface and expert guidance, achieving your health goals has
                never been easier. Join us today and start building a stronger, healthier you!</p>
            <div class="buttons">
                <a href="HeavyMetals/admin_dashboard/#about-header" class="cta-button">About Us</a>
                <a href="HeavyMetals/admin_dashboard/#faq" class="cta-button secondary">FAQ</a>
            </div>
        </div>
        <div class="hero-image">
            <img src="HeavyMetals/admin_dashboard/assets/images/mobile-app.svg" alt="Mobile App">
            <img src="HeavyMetals/admin_dashboard/assets/images/mobile-app2.svg" alt="Mobile App">
        </div>
    </section>

    <!-- Features Section -->
    <section class="features-section">
        <!-- Main Header and Description -->
        <div class="header-content">
            <h1>Exercise Like Never Before</h1>
            <p class="description">
                Heavy Metals app is your go-to fitness app, offering personalized training plans and a library of exercises.
            </p>
        </div>

        <!-- Content Container (Feature List on the Left, Mockup on the Right) -->
        <div class="feature-content">
            <div class="feature-list">
                <div class="feature-item">
                    <img src="HeavyMetals/admin_dashboard/icons/workout-ic.svg" alt="Personalized Workouts">
                    <div class="feature-text">
                        <h3>Personalized Workouts</h3>
                        <p>Workouts tailored specifically for you.</p>
                    </div>
                </div>
                <div class="feature-item">
                    <img src="HeavyMetals/admin_dashboard/icons/track-ic.svg" alt="Stay on Track">
                    <div class="feature-text">
                        <h3>Stay on Track</h3>
                        <p>Stay motivated with personal trainers.</p>
                    </div>
                </div>
                <div class="feature-item">
                    <img src="HeavyMetals/admin_dashboard/icons/goal-ic.svg" alt="Focus on Goal">   
                    <div class="feature-text">
                        <h3>Focus on Your Goal</h3>
                        <p>Target-specific training for maximum results.</p>
                    </div>
                </div>
                <div class="feature-item">
                    <img src="HeavyMetals/admin_dashboard/icons/equipment-ic.svg" alt="Wide Range of Equipment">
                    <div class="feature-text">
                        <h3>Wide Range of Equipment</h3>
                        <p>Access to premium gym equipment.</p>
                    </div>
                </div>
            </div>

            <!-- Mockup on the Right -->
            <div class="feature-image">
                <img src="HeavyMetals/admin_dashboard/assets/images/feature-mobile-app.png" alt="Mobile App">
            </div>
        </div>
    </section>

    <!-- about us section-->
    <section class="about-section">
        <h1 id="about-header">About Us</h1>
        <div class="info-container">

            <div class="info">
                <div class="contact-info">
                    <img src="HeavyMetals/admin_dashboard/icons/location-ic.png" class="info-icon" alt="Location Icon">
                    <p>30 Lucio Lopez Drive, V. Rama, Cebu City</p>
                </div>

                <div class="contact-info">
                         <img src="HeavyMetals/admin_dashboard/icons/facebook-ic.png" class="info-icon" alt="Facebook Icon">  
                         <a href="https://www.facebook.com/HeavyMetalsFitnessCenter" target="_blank" class="social-link"> Heavy Metals Fitness Center</a>
                </div>

                <div class="contact-info">
                   <img src="HeavyMetals/admin_dashboard/icons/phone-ic.png" class="info-icon" alt="Phone Icon">
                    <a href="tel:09292839913" class="phone-link"> 0929 283 9913</a>
                </div>
            </div>

            <div class="images">
                <iframe 
                    src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d4639.584587104706!2d123.88350262824963!3d10.30297027956135!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x33a99eab413134dd%3A0x2e93c0d8be2e82f5!2sHeavy%20Metals%20Fitness%20Center!5e1!3m2!1sen!2sph!4v1728076558094!5m2!1sen!2sph" width="400" height="300" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade">
                </iframe>
                
                <!-- Image of the Gym Location -->
                <iframe 
                    src="https://www.google.com/maps/embed?pb=!3m2!1sen!2sph!4v1728076688605!5m2!1sen!2sph!6m8!1m7!1s8cF_mKGOh9wbJGp7tXpJ5g!2m2!1d10.30249453111152!2d123.8847972343071!3f213.2835110756315!4f-14.635754395557669!5f0.7820865974627469" width="400" height="300" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade">
                </iframe>
            </div>
                
        </div>
    </section>

    <!-- Call to Action Section -->
    <section id="cta" class="cta">
        <h2>Get Started with Heavy Metals</h2>
        <a href="#" class="cta-button">Join Now</a>
    </section>

    <!-- Footer -->
    <footer>
        <p>&copy; 2024 Heavy Metals. All Rights Reserved.</p>
    </footer>
</body>
</html>
