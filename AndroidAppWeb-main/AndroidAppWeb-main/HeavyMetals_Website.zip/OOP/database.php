<?php
// Database connection settings
$host = 'localhost';   // Replace with your database host
$db = "u843230181_Heavy_Metals";    // Replace with your database name
$username = "u843230181_heavymetals";
$password = "Heavymetals2024";     // Replace with your database password (if applicable)
$charset = 'utf8mb4';
 
// Create connection using MySQLi
$conn = new mysqli($host, $username, $password, $db);

// Check connection
if ($conn->connect_error) {
    die('Connection failed: ' . $conn->connect_error);
}

?>