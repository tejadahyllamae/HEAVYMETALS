<?php
// Enable error reporting for debugging
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

header('Content-Type: application/json');
header("Cache-Control: no-store, no-cache, must-revalidate, max-age=0");
header("Pragma: no-cache");

require 'database.php'; // Include your database connection

$response = array();

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $username = $_POST['username'];
    $password = $_POST['password'];

    if (!empty($username) && !empty($password)) {
        // Prepare SQL query to check if the user already exists
        $stmt = $conn->prepare("SELECT * FROM users WHERE username = ?");
        $stmt->bind_param("s", $username);
        $stmt->execute();
        $result = $stmt->get_result();

        // Check if the user already exists
        if ($result->num_rows > 0) {
            $response['success'] = 0;
            $response['message'] = "Username already exists. Please choose a different username.";
        } else {
            // Insert new user into the database
            $stmt = $conn->prepare("INSERT INTO users (username, password) VALUES (?, ?)");
            $stmt->bind_param("ss", $username, $password);

            if ($stmt->execute()) {
                $response['success'] = 1;
                $response['message'] = "Registration successful";
            } else {
                $response['success'] = 0;
                $response['message'] = "Registration failed. Please try again.";
            }
        }

        $stmt->close();
    } else {
        $response['success'] = 0;
        $response['message'] = "Missing required fields.";
    }
} else {
    $response['success'] = 0;
    $response['message'] = "Invalid request method.";
}

echo json_encode($response);
?>
