<?php

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require 'vendor/autoload.php'; // Load PHPMailer dependencies
require 'database.php'; // Include MySQLi connection

$response = ['success' => 0, 'message' => '']; // Default response structure

// Sanitize inputs
$firstName = htmlspecialchars($_POST['first_name'] ?? '');
$lastName = htmlspecialchars($_POST['last_name'] ?? '');
$email = strtolower(filter_var($_POST['email'] ?? '', FILTER_SANITIZE_EMAIL));
$password = $_POST['password'] ?? '';
$passwordConfirmation = $_POST['passwordConfirmation'] ?? '';

// Validate input
if (!filter_var($email, FILTER_VALIDATE_EMAIL) || empty($password) || empty($passwordConfirmation) || empty($firstName) || empty($lastName)) {
    $response['message'] = 'Invalid input. Please check your details.';
    echo json_encode($response);
    exit;
}

if ($password !== $passwordConfirmation) {
    $response['message'] = 'Passwords do not match.';
    echo json_encode($response);
    exit;
}

// Check if email already exists in the user_register table (case-insensitive)
$stmt = $conn->prepare("SELECT email FROM user_register WHERE email = LOWER(?)");
if (!$stmt) {
    $response['message'] = 'Failed to prepare SQL statement.';
    echo json_encode($response);
    exit;
}

$stmt->bind_param("s", $email);
$stmt->execute();
$stmt->store_result(); // Store the result to get the number of rows

if ($stmt->num_rows > 0) {
    $response['message'] = 'Email is already taken. Please try logging in or using a different email.';
    echo json_encode($response);
    exit;
}

// Registration logic follows here...
$verification_token = bin2hex(random_bytes(16)); // 32 characters long token for email verification
$hashedPassword = password_hash($password, PASSWORD_BCRYPT);

// Insert new user into the user_register table with a created_at timestamp
$stmt = $conn->prepare("INSERT INTO user_register (first_name, last_name, email, password, verification_token, is_verified, created_at) VALUES (?, ?, ?, ?, ?, 0, NOW())");
if (!$stmt) {
    $response['message'] = 'Failed to prepare SQL statement for insert.';
    echo json_encode($response);
    exit;
}

$stmt->bind_param("sssss", $firstName, $lastName, $email, $hashedPassword, $verification_token);

if ($stmt->execute()) {
    // Set up PHPMailer to send the verification email
    try {
        $mail = new PHPMailer(true);
        $mail->isSMTP();
        $mail->Host = 'smtp.gmail.com';
        $mail->SMTPAuth = true;
        $mail->Username = 'heavymetalscebu@gmail.com'; 
        $mail->Password = 'ppwy zvfk rgfl jsod'; 
        $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
        $mail->Port = 587;

        $mail->setFrom('heavymetalscebu@gmail.com', 'Heavy Metals');
        $mail->addAddress($email); 

        // Construct the verification link
        $verification_link = "https://heavymetals.scarlet2.io/HeavyMetals/verify.html?token=$verification_token";

        // Email content
        $mail->isHTML(true);
        $mail->Subject = 'Email Verification';
        $mail->Body = "Please click the following link to verify your email address: <a href='$verification_link'>Verify Email</a>";

        $mail->send();

        // Registration successful
        $response['success'] = 1;
        $response['message'] = 'Registration successful. Please check your email to verify your account.';
        $response['email'] = $email;          // Return email for client to identify the logged-in user
    } catch (Exception $e) {
        $response['message'] = 'Mail could not be sent. Error: ' . $mail->ErrorInfo;
    }
} else {
    $response['message'] = 'Registration failed. Please try again.';
}

// Close the prepared statement and database connection
$stmt->close();
$conn->close();

// Output the response as JSON
echo json_encode($response);
exit;
?>
