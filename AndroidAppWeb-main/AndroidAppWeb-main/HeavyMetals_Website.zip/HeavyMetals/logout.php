<?php
header('Content-Type: application/json');
require 'database.php'; // Include MySQLi connection

// Get the session token from the request
$session_token = $_POST['session_token'] ?? '';

// Input validation
if (empty($session_token)) {
    echo json_encode(["success" => 0, "message" => "Session token is required."]);
    exit;
}

// Clear the session token in the database
$stmt = $conn->prepare("UPDATE user_register SET session_token = NULL WHERE session_token = ?");
$stmt->bind_param("s", $session_token);

if ($stmt->execute()) {
    echo json_encode(["success" => 1, "message" => "Logged out successfully."]);
} else {
    echo json_encode(["success" => 0, "message" => "Failed to log out."]);
}

$stmt->close();
$conn->close();
?>
