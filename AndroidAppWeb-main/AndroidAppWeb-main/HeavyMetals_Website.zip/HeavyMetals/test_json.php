<?php
// Get raw input
$raw_data = file_get_contents('php://input');
echo "Raw Data: " . $raw_data . "<br>";

// Try to decode JSON
$data = json_decode($raw_data, true);

if (json_last_error() !== JSON_ERROR_NONE) {
    echo "JSON decode error: " . json_last_error_msg();
} else {
    echo "<pre>";
    print_r($data);
    echo "</pre>";
}
?>
