<?php
require 'database.php';

// Define the cleanup time limit (e.g., 20 minutes)
$time_limit = 1 * 60; // 20 minutes in seconds

// Query to delete unverified users who registered more than 20 minutes ago
$stmt = $conn->prepare("DELETE FROM user_register WHERE is_verified = 0 AND TIMESTAMPDIFF(SECOND, created_at, NOW()) > ?");
$stmt->bind_param("i", $time_limit);

if ($stmt->execute()) {
    echo "Unverified users cleaned up.";
} else {
    echo "Cleanup failed.";
}

$stmt->close();
$conn->close();
?>
