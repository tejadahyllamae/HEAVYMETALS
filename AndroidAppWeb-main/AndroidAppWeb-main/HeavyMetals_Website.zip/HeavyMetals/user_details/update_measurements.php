<?php
// Include the database connection
require '../database.php';

header('Content-Type: application/json'); // Set the response to be in JSON format

// Check if user_id is set, which is mandatory
if (isset($_POST['user_id'])) {
    $user_id = (int)$_POST['user_id']; // Convert user_id to integer

    // Start building the SQL query with dynamic parts
    $fields = [];
    $types = '';
    $values = [];

    // Check and add each field only if it's set in the POST request
    if (isset($_POST['body_weight'])) {
        $fields[] = "body_weight = ?";
        $types .= 'd';
        $values[] = (float)$_POST['body_weight'];
    }
    if (isset($_POST['height'])) {
        $fields[] = "height = ?";
        $types .= 'd';
        $values[] = (float)$_POST['height'];
    }
    if (isset($_POST['chest'])) {
        $fields[] = "chest = ?";
        $types .= 'd';
        $values[] = (float)$_POST['chest'];
    }
    if (isset($_POST['shoulder'])) {
        $fields[] = "shoulder = ?";
        $types .= 'd';
        $values[] = (float)$_POST['shoulder'];
    }
    if (isset($_POST['waist'])) {
        $fields[] = "waist = ?";
        $types .= 'd';
        $values[] = (float)$_POST['waist'];
    }
    if (isset($_POST['hips'])) {
        $fields[] = "hips = ?";
        $types .= 'd';
        $values[] = (float)$_POST['hips'];
    }
    if (isset($_POST['left_bicep'])) {
        $fields[] = "left_bicep = ?";
        $types .= 'd';
        $values[] = (float)$_POST['left_bicep'];
    }
    if (isset($_POST['right_bicep'])) {
        $fields[] = "right_bicep = ?";
        $types .= 'd';
        $values[] = (float)$_POST['right_bicep'];
    }
    if (isset($_POST['left_forearm'])) {
        $fields[] = "left_forearm = ?";
        $types .= 'd';
        $values[] = (float)$_POST['left_forearm'];
    }
    if (isset($_POST['right_forearm'])) {
        $fields[] = "right_forearm = ?";
        $types .= 'd';
        $values[] = (float)$_POST['right_forearm'];
    }
    if (isset($_POST['left_calf'])) {
        $fields[] = "left_calf = ?";
        $types .= 'd';
        $values[] = (float)$_POST['left_calf'];
    }
    if (isset($_POST['right_calf'])) {
        $fields[] = "right_calf = ?";
        $types .= 'd';
        $values[] = (float)$_POST['right_calf'];
    }

    // Add BMI field only if it's sent
    if (isset($_POST['bmi'])) {
        $bmi_sql = "UPDATE fitness_declaration_3 SET bmi = ? WHERE user_id = ?";
        $stmt2 = $conn->prepare($bmi_sql);
        $stmt2->bind_param('di', $_POST['bmi'], $user_id);
        $stmt2->execute();
        $stmt2->close();
    }

    // Proceed only if there's something to update
    if (!empty($fields)) {
        $sql = "UPDATE fitness_declaration SET " . implode(', ', $fields) . " WHERE user_id = ?";
        $types .= 'i'; // Append type for user_id
        $values[] = $user_id;

        // Prepare and execute the update statement
        if ($stmt = $conn->prepare($sql)) {
            $stmt->bind_param($types, ...$values);

            if ($stmt->execute()) {
                echo json_encode(['success' => true, 'message' => 'Measurements updated successfully.']);
            } else {
                echo json_encode(['success' => false, 'message' => 'Failed to update measurements.']);
            }
            $stmt->close();
        } else {
            echo json_encode(['success' => false, 'message' => 'Failed to prepare SQL statement.']);
        }
    } else {
        echo json_encode(['success' => false, 'message' => 'No data to update.']);
    }

    // Close the database connection
    $conn->close();
} else {
    // If user_id is missing
    echo json_encode(['success' => false, 'message' => 'Missing required data.']);
}
?>
