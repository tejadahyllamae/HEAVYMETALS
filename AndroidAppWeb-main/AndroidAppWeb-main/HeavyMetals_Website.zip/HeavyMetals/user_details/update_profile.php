<?php
// Include your database connection settings
require '../database.php';  // Adjust the path to point to your database.php file

// Assume that the following data comes from a form or API request
$user_id = $_POST['user_id'];
$profile_pic = $_POST['profile_pic'];
$date_of_birth = $_POST['date_of_birth'];

if (empty($user_id)) {
    echo json_encode(['success' => false, 'message' => 'No user ID provided']);
    exit();
}

try {
    // Prepare an SQL statement to update the profile
    $stmt = $conn->prepare('UPDATE user_profile
                            SET profile_pic = ?, date_of_birth = ?
                            WHERE user_id = ?');

    // Bind parameters
    $stmt->bind_param('ssi', $profile_pic, $date_of_birth, $user_id);

    // Execute the query
    if ($stmt->execute()) {
        echo json_encode(['success' => true, 'message' => 'Profile updated successfully']);
    } else {
        echo json_encode(['success' => false, 'message' => 'Failed to update profile']);
    }

    // Close the statement
    $stmt->close();

} catch (Exception $e) {
    echo json_encode(['success' => false, 'message' => 'Failed to update profile: ' . $e->getMessage()]);
}

// Close the connection
$conn->close();
?>
