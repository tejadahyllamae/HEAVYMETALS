<?php
// Include the database connection
require '../database.php';

header('Content-Type: application/json');  // Set the content type to JSON

// Check if all necessary POST data is set
if (isset($_POST['user_id']) && isset($_POST['bmi']) && isset($_POST['workout_experience']) 
    && isset($_POST['strength_experience']) && isset($_POST['training_days'])) {

    // Retrieve POST data
    $user_id = (int) $_POST['user_id'];  // Convert user_id to integer
    $bmi = (float) $_POST['bmi'];  // Convert bmi to float
    $workout_experience = $_POST['workout_experience'];  // 'YES' or 'NO'
    $strength_experience = $_POST['strength_experience'];  // User's strength experience
    $training_days = $_POST['training_days'];  // Training days (1-2 days, 3-4 days, 5+ days)

    // Prepare SQL query to insert the data into the fitness_declaration_3 table
    $sql = "INSERT INTO fitness_declaration_3 (user_id, bmi, workout_experience, strength_experience, training_days)
            VALUES (?, ?, ?, ?, ?)";

    // Prepare the statement
    if ($stmt = $conn->prepare($sql)) {
        // Bind the parameters to the query
        $stmt->bind_param('idsss', $user_id, $bmi, $workout_experience, $strength_experience, $training_days);

        // Execute the query
        if ($stmt->execute()) {
            // If the execution is successful
            echo json_encode([
                'success' => true,
                'message' => 'Fitness declaration saved successfully.'
            ]);
        } else {
            // If there is an execution error
            echo json_encode([
                'success' => false,
                'message' => 'Failed to save fitness declaration. Please try again.'
            ]);
        }

        // Close the prepared statement
        $stmt->close();
    } else {
        // If the statement preparation fails
        echo json_encode([
            'success' => false,
            'message' => 'Failed to prepare SQL statement.'
        ]);
    }

    // Close the database connection
    $conn->close();
} else {
    // If any required POST data is missing
    echo json_encode([
        'success' => false,
        'message' => 'Missing required data.'
    ]);
}
?>
