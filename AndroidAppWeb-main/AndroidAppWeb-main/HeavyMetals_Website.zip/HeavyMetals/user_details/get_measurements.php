<?php
// Include database connection
require '../database.php';

header('Content-Type: application/json'); // Set the response to be in JSON format

// Check if 'user_id' is provided in the POST request
if (isset($_POST['user_id'])) {
    $user_id = trim($_POST['user_id']); // Sanitize the user_id

    // Ensure the user_id is not empty
    if (!empty($user_id)) {

        // Query to fetch all measurement data from the measurements table and BMI from the fitness_declaration_3 table
        $sql = "SELECT fd.body_weight, fd.height, fd.chest, fd.shoulder, fd.waist, fd.hips, 
                       fd.left_bicep, fd.right_bicep, fd.left_forearm, fd.right_forearm, 
                       fd.left_calf, fd.right_calf, fd.date_created, fd3.bmi
                FROM fitness_declaration AS fd
                LEFT JOIN fitness_declaration_3 AS fd3 ON fd.user_id = fd3.user_id
                WHERE fd.user_id = ?";  // Query by user_id

        // Prepare and execute the SQL statement
        if ($stmt = $conn->prepare($sql)) {
            $stmt->bind_param('i', $user_id); // 'i' represents an integer

            if ($stmt->execute()) {
                $result = $stmt->get_result();

                if ($result->num_rows > 0) {
                    // Fetch all measurement data as an associative array
                    $measurements = $result->fetch_assoc();

                    // Return the data as JSON
                    echo json_encode([
                        'success' => true,
                        'measurements' => $measurements
                    ]);
                } else {
                    // If no data is found
                    echo json_encode(['success' => false, 'message' => 'No measurements found']);
                }
            } else {
                // Execution error
                echo json_encode(['success' => false, 'message' => 'Failed to execute SQL statement']);
            }

            // Close the prepared statement
            $stmt->close();
        } else {
            // SQL preparation failure
            echo json_encode(['success' => false, 'message' => 'Failed to prepare SQL statement']);
        }

        // Close the database connection
        $conn->close();
    } else {
        // If user_id is empty after trimming
        echo json_encode(['success' => false, 'message' => 'user_id is empty']);
    }
} else {
    // If no user_id is provided
    echo json_encode(['success' => false, 'message' => 'Missing user_id']);
}
?>
