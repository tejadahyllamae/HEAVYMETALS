<?php
// Include the database connection
require '../database.php';

header('Content-Type: application/json'); // Set the response to be in JSON format

// Check if a specific user_id is provided
if (isset($_POST['user_id'])) {
    $user_id = (int) $_POST['user_id']; // Sanitize the user_id input

    // Prepare the SQL query to fetch the user goals based on user_id
    $sql = "SELECT lose_weight, increase_strength, build_muscle, mobility, wellness_reduce_stress, fitness 
            FROM user_goals WHERE user_id = ?";

    if ($stmt = $conn->prepare($sql)) {
        // Bind the user_id parameter
        $stmt->bind_param('i', $user_id);

        // Execute the query
        $stmt->execute();

        // Fetch the result
        $result = $stmt->get_result();

        if ($result->num_rows > 0) {
            // Fetch the data as an associative array
            $user_goals = $result->fetch_assoc();

            // Return the user goals as a JSON response
            echo json_encode(['success' => true, 'user_goals' => $user_goals]);
        } else {
            // If no records found, return a failure response
            echo json_encode(['success' => false, 'message' => 'No goals found for the given user_id']);
        }

        // Close the statement
        $stmt->close();
    } else {
        // If the SQL query fails to prepare
        echo json_encode(['success' => false, 'message' => 'Failed to prepare SQL query']);
    }

    // Close the database connection
    $conn->close();
} else {
    // If no user_id is provided in the request
    echo json_encode(['success' => false, 'message' => 'Missing user_id']);
}
?>
