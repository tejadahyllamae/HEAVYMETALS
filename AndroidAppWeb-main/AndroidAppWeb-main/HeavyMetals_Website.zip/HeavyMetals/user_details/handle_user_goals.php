<?php
// Include database connection
require '../database.php';

header('Content-Type: application/json'); // Ensure the response is JSON

// Check if the necessary POST data is set
if (isset($_POST['user_id']) && isset($_POST['lose_weight']) && isset($_POST['increase_strength']) && 
    isset($_POST['build_muscle']) && isset($_POST['mobility']) && 
    isset($_POST['wellness_reduce_stress']) && isset($_POST['fitness'])) {

    // Retrieve POST data
    $user_id = (int) $_POST['user_id'];
    $lose_weight = (int) $_POST['lose_weight'];
    $increase_strength = (int) $_POST['increase_strength'];
    $build_muscle = (int) $_POST['build_muscle'];
    $mobility = (int) $_POST['mobility'];
    $wellness_reduce_stress = (int) $_POST['wellness_reduce_stress'];
    $fitness = (int) $_POST['fitness'];

    // Check if user_id exists in user_register table
    $check_user_sql = "SELECT user_id FROM user_register WHERE user_id = ?";
    $check_stmt = $conn->prepare($check_user_sql);
    $check_stmt->bind_param('i', $user_id);
    $check_stmt->execute();
    $check_stmt->store_result();

    if ($check_stmt->num_rows == 0) {
        echo json_encode([
            'success' => false,
            'message' => 'Invalid user ID.'
        ]);
        exit();
    }
    $check_stmt->close();

    // Ensure that the selected goals do not exceed 3
    $selectedGoals = $lose_weight + $increase_strength + $build_muscle + $mobility + $wellness_reduce_stress + $fitness;

    if ($selectedGoals > 3) {
        echo json_encode([
            'success' => false,
            'message' => 'You can select only up to 3 goals.'
        ]);
        exit();
    }

    // Insert or update the user's selected goals in the database
    $sql = "REPLACE INTO user_goals (user_id, lose_weight, increase_strength, build_muscle, mobility, wellness_reduce_stress, fitness)
            VALUES (?, ?, ?, ?, ?, ?, ?)";

    if ($stmt = $conn->prepare($sql)) {
        // Bind the parameters: user_id, lose_weight, increase_strength, build_muscle, mobility, wellness_reduce_stress, fitness
        $stmt->bind_param('iiiiiii', $user_id, $lose_weight, $increase_strength, $build_muscle, $mobility, $wellness_reduce_stress, $fitness);

        // Execute the query
        if ($stmt->execute()) {
            echo json_encode([
                'success' => true,
                'message' => 'Goals successfully saved.'
            ]);
        } else {
            // Query execution error
            echo json_encode([
                'success' => false,
                'message' => 'Failed to save goals. Please try again.'
            ]);
        }

        // Close the statement
        $stmt->close();
    } else {
        // Query preparation error
        echo json_encode([
            'success' => false,
            'message' => 'Failed to prepare SQL statement.'
        ]);
    }

    // Close the database connection
    $conn->close();
} else {
    // If required POST data is missing
    echo json_encode([
        'success' => false,
        'message' => 'Missing required data.'
    ]);
}
