<?php
// Include database connection
require '../database.php';

header('Content-Type: application/json'); // Ensure the response is in JSON format

// Check if the necessary POST data is set
if (isset($_POST['user_id']) && isset($_POST['gender']) && isset($_POST['body_weight']) && isset($_POST['height']) &&
    isset($_POST['chest']) && isset($_POST['shoulder']) && isset($_POST['waist']) && isset($_POST['hips']) &&
    isset($_POST['left_bicep']) && isset($_POST['right_bicep']) && isset($_POST['left_forearm']) &&
    isset($_POST['right_forearm']) && isset($_POST['left_calf']) && isset($_POST['right_calf'])) {

    // Retrieve and sanitize POST data
    $user_id = (int) $_POST['user_id'];
    $gender = $_POST['gender'];
    $body_weight = (float) $_POST['body_weight'];
    $height = (float) $_POST['height'];
    $chest = (float) $_POST['chest'];
    $shoulder = (float) $_POST['shoulder'];
    $waist = (float) $_POST['waist'];
    $hips = (float) $_POST['hips'];
    $left_bicep = (float) $_POST['left_bicep'];
    $right_bicep = (float) $_POST['right_bicep'];
    $left_forearm = (float) $_POST['left_forearm'];
    $right_forearm = (float) $_POST['right_forearm'];
    $left_calf = (float) $_POST['left_calf'];
    $right_calf = (float) $_POST['right_calf'];

    // Validate gender
    if (!in_array($gender, ['male', 'female'])) {
        echo json_encode([
            'success' => false,
            'message' => 'Invalid gender value.'
        ]);
        exit();
    }

    // Prepare SQL statement to insert the fitness declaration
    $sql = "INSERT INTO fitness_declaration (user_id, gender, body_weight, height, chest, shoulder, waist, hips, left_bicep, right_bicep, left_forearm, right_forearm, left_calf, right_calf)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

    // Prepare and execute the query
    if ($stmt = $conn->prepare($sql)) {
        // Bind parameters (s = string, i = integer, d = double/decimal)
        $stmt->bind_param('isdddddddddddd', $user_id, $gender, $body_weight, $height, $chest, $shoulder, $waist, $hips, $left_bicep, $right_bicep, $left_forearm, $right_forearm, $left_calf, $right_calf);

        // Execute the query and check if successful
        if ($stmt->execute()) {
            echo json_encode([
                'success' => true,
                'message' => 'Fitness declaration saved successfully!'
            ]);
        } else {
            // Query execution error
            echo json_encode([
                'success' => false,
                'message' => 'Failed to save fitness declaration. Please try again.'
            ]);
        }

        // Close the statement
        $stmt->close();
    } else {
        // SQL query preparation error
        echo json_encode([
            'success' => false,
            'message' => 'Failed to prepare SQL statement.'
        ]);
    }

    // Close the database connection
    $conn->close();
} else {
    // If required POST data is missing
    echo json_encode([
        'success' => false,
        'message' => 'Missing required data.'
    ]);
}
?>
