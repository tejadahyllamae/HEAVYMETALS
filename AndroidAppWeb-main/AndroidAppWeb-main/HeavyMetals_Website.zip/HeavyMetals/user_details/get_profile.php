<?php
// Include database connection
require '../database.php';

header('Content-Type: application/json'); // Ensure the response is JSON

if (isset($_POST['user_id'])) {
    $user_id = trim($_POST['user_id']); // Trim to remove unnecessary whitespace

    // Ensure the user_id is not empty after trimming
    if (!empty($user_id)) {

        // Query to fetch first name, last name, phone_number from user_register, profile_pic, date_of_birth from user_profile, and gender from fitness_declaration
        $sql = "SELECT ur.first_name, ur.last_name, ur.phone_number, up.profile_pic, up.date_of_birth, fd.gender 
                FROM user_register ur
                LEFT JOIN user_profile up ON ur.user_id = up.user_id
                LEFT JOIN fitness_declaration fd ON ur.user_id = fd.user_id
                WHERE ur.user_id = ?";  // Query by user_id

        // Prepare and execute the query
        if ($stmt = $conn->prepare($sql)) {
            $stmt->bind_param('i', $user_id);  // 'i' means the parameter is an integer

            if ($stmt->execute()) {
                $result = $stmt->get_result();

                if ($result->num_rows > 0) {
                    // Fetch the result as an associative array
                    $row = $result->fetch_assoc();

                    // Return the profile data, including phone_number and gender
                    echo json_encode([
                        'success' => true,
                        'profile' => [
                            'first_name' => $row['first_name'],
                            'last_name' => $row['last_name'],
                            'phone_number' => $row['phone_number'],  // Add phone number
                            'profile_pic' => $row['profile_pic'],
                            'date_of_birth' => $row['date_of_birth'],
                            'gender' => $row['gender']  // Add gender from fitness_declaration
                        ]
                    ]);
                    
                } else {
                    // If no profile is found, return an error
                    echo json_encode(['success' => false, 'message' => 'Profile not found']);
                }
            } else {
                // Execution error
                echo json_encode(['success' => false, 'message' => 'Failed to execute SQL statement']);
            }

            // Close statement
            $stmt->close();
        } else {
            // If query preparation fails
            echo json_encode(['success' => false, 'message' => 'Failed to prepare SQL statement']);
        }

        // Close the connection
        $conn->close();

    } else {
        // If user_id is empty after trimming
        echo json_encode(['success' => false, 'message' => 'user_id is empty']);
    }
} else {
    // If no user_id is provided in POST
    echo json_encode(['success' => false, 'message' => 'Missing user_id']);
}
?>
