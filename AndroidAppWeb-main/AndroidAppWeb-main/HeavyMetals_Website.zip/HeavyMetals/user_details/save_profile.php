<?php 
// Include your database connection settings
require '../database.php';  // Adjust the path to point to your database.php file

// Define the directory to store images
$imageDir = 'images/';  // Adjust the path to point to your 'images' directory

// Create the images directory if it doesn't exist
if (!is_dir($imageDir)) {
    mkdir($imageDir, 0755, true);  // Create the directory with appropriate permissions
}

// Check if the required POST fields are set
if (isset($_POST['user_id']) && isset($_POST['first_name']) && isset($_POST['last_name']) && isset($_POST['phone_number'])) {

    // Fetch the data from the POST request
    $user_id = $_POST['user_id'];
    $first_name = $_POST['first_name'];
    $last_name = $_POST['last_name'];
    $phone_number = $_POST['phone_number'];
    $date_of_birth = isset($_POST['date_of_birth']) ? $_POST['date_of_birth'] : null; // Optional field

    // Variable to store new profile picture filename, if available
    $fileName = null;

    // Check if a new profile picture is provided in the request
    if (isset($_FILES['profile_pic']) && $_FILES['profile_pic']['error'] == 0) {
        $profilePic = $_FILES['profile_pic'];

        // Extract file extension and create a unique filename
        $fileExt = pathinfo($profilePic['name'], PATHINFO_EXTENSION);
        $fileName = uniqid() . '.' . $fileExt;

        // Move the uploaded file to the images directory
        $targetFilePath = $imageDir . $fileName;
        if (!move_uploaded_file($profilePic['tmp_name'], $targetFilePath)) {
            // Failed to move uploaded file
            echo json_encode(['success' => false, 'message' => 'Failed to upload profile picture']);
            exit();
        }

        // Update the profile picture in the user_profile table
        try {
            $stmt = $conn->prepare("UPDATE user_profile SET profile_pic = ? WHERE user_id = ?");
            if ($stmt === false) {
                echo json_encode(['success' => false, 'message' => 'Failed to prepare statement for profile picture: ' . $conn->error]);
                exit();
            }
            $stmt->bind_param('si', $fileName, $user_id);
            if (!$stmt->execute()) {
                echo json_encode(['success' => false, 'message' => 'Failed to update profile picture: ' . $stmt->error]);
                exit();
            }
            $stmt->close();
        } catch (Exception $e) {
            echo json_encode(['success' => false, 'message' => 'Exception when updating profile picture: ' . $e->getMessage()]);
            exit();
        }
    }

    // Update the profile details in both the user_register and user_profile tables
    try {
        // 1. Update first_name, last_name, and phone_number in user_register table
        $sql = "UPDATE user_register SET first_name = ?, last_name = ?, phone_number = ? WHERE user_id = ?";
        $stmt = $conn->prepare($sql);
        if ($stmt === false) {
            echo json_encode(['success' => false, 'message' => 'Failed to prepare statement: ' . $conn->error]);
            exit();
        }
        $stmt->bind_param('sssi', $first_name, $last_name, $phone_number, $user_id);
        $stmt->execute();
        $stmt->close();

        // 2. Update date_of_birth in user_profile table
        if (!empty($date_of_birth)) {
            $stmt = $conn->prepare("UPDATE user_profile SET date_of_birth = ? WHERE user_id = ?");
            if ($stmt === false) {
                echo json_encode(['success' => false, 'message' => 'Failed to prepare statement for date of birth: ' . $conn->error]);
                exit();
            }
            $stmt->bind_param('si', $date_of_birth, $user_id);
            $stmt->execute();
            $stmt->close();
        }

        echo json_encode(['success' => true, 'message' => 'Profile updated successfully']);

    } catch (Exception $e) {
        echo json_encode(['success' => false, 'message' => 'Exception: ' . $e->getMessage()]);
    }

    // Close the database connection
    $conn->close();

} else {
    // Return an error if required fields are not provided
    echo json_encode(['success' => false, 'message' => 'Missing required fields (user_id, first_name, last_name, phone_number)']);
}
