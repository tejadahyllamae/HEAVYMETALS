<?php
// Set content type to JSON for proper response
header('Content-Type: application/json');

// Database connection settings
require 'database.php';  // Ensure this points to the correct file path
$dsn = "mysql:host=$host;dbname=$db;charset=$charset";
$options = [
    PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
    PDO::ATTR_EMULATE_PREPARES   => false,
];

try {
    // Connect to the database using PDO
    $pdo = new PDO($dsn, $username, $password, $options);
} catch (\PDOException $e) {
    // If connection fails, return the error message
    echo json_encode(['success' => false, 'message' => 'Database connection failed: ' . $e->getMessage()]);
    exit();
}

// Check if the 'email' field is provided via POST and validate it
if (isset($_POST['email'])) {
    $email = $_POST['email'];

    // Validate email format
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        echo json_encode(['success' => false, 'message' => 'Invalid email format']);
        exit();
    }

    // Prepare SQL query to fetch first_name and last_name for the provided email
    $stmt = $pdo->prepare('SELECT first_name, last_name FROM user_register WHERE email = :email');
    $stmt->bindParam(':email', $email, PDO::PARAM_STR);
    $stmt->execute();
    $user = $stmt->fetch();

    if ($user) {
        // Return user data in JSON format, including email
        echo json_encode([
            'success' => true,
            'first_name' => $user['first_name'],
            'last_name' => $user['last_name'],
            'email' => $email  // Include the email in the response
        ]);
    } else {
        // If no user is found, return a "User not found" message
        echo json_encode(['success' => false, 'message' => 'User not found']);
    }
} else {
    // If 'email' is not provided in POST request
    echo json_encode(['success' => false, 'message' => 'Email not provided']);
}
?>
