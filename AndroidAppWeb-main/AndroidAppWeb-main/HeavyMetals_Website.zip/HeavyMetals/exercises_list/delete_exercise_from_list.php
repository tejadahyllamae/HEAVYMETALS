<?php
header('Content-Type: application/json');
require '../database.php';

// Get POST data
$exercise_id = $_POST['exercise_id'] ?? '';

// Validate input
if (empty($exercise_id)) {
    echo json_encode(["success" => 0, "message" => "Exercise ID is required."]);
    exit;
}

// Mark the exercise as inactive in the exercises_list table
$stmt = $conn->prepare("UPDATE exercises_list SET is_active = 0 WHERE id = ?");
$stmt->bind_param("i", $exercise_id);

if ($stmt->execute()) {
    echo json_encode(["success" => 1, "message" => "Exercise deleted successfully."]);
} else {
    echo json_encode(["success" => 0, "message" => "Failed to delete exercise."]);
}

$stmt->close();
$conn->close();
?>
