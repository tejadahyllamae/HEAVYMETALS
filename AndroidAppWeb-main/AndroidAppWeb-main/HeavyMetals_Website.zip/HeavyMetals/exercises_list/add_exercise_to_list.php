<?php
header('Content-Type: application/json');
require '../database.php';

// Get POST data
$exercise_name = $_POST['exercise_name'] ?? '';
$description = $_POST['description'] ?? '';
$image_url = $_POST['image_url'] ?? '';  // Image URL

// Validate input
if (empty($exercise_name)) {
    echo json_encode(["success" => 0, "message" => "Exercise name is required."]);
    exit;
}

// Optional: Validate image URL (if provided)
if (!empty($image_url) && !filter_var($image_url, FILTER_VALIDATE_URL)) {
    echo json_encode(["success" => 0, "message" => "Invalid image URL."]);
    exit;
}

// Insert the new exercise into the exercises_list table
$stmt = $conn->prepare("INSERT INTO exercises_list (exercise_name, description, image_url) VALUES (?, ?, ?)");
$stmt->bind_param("sss", $exercise_name, $description, $image_url);

if ($stmt->execute()) {
    echo json_encode(["success" => 1, "message" => "Exercise added successfully."]);
} else {
    echo json_encode(["success" => 0, "message" => "Failed to add exercise."]);
}

$stmt->close();
$conn->close();
?>
