<?php
header('Content-Type: application/json');
require '../database.php';

// Check if a category is provided in the request (via GET or POST)
$category = isset($_REQUEST['category']) ? $_REQUEST['category'] : '';

// Prepare the SQL query to fetch exercises
if (!empty($category)) {
    // If a category is provided, fetch exercises only from that category
    $stmt = $conn->prepare("SELECT id, exercise_name, category, image_url FROM exercises_list WHERE is_active = 1 AND category = ?");
    $stmt->bind_param("s", $category);
} else {
    // If no category is provided, fetch all active exercises
    $stmt = $conn->prepare("SELECT id, exercise_name, category, image_url FROM exercises_list WHERE is_active = 1");
}

$stmt->execute();
$result = $stmt->get_result();

$exercises = [];
while ($row = $result->fetch_assoc()) {
    $exercises[] = $row;
}

// Return the exercises as JSON
echo json_encode([
    "success" => 1,
    "exercises" => $exercises
]);

$stmt->close();
$conn->close();
?>
