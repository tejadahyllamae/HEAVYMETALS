<?php
// Include your database connection and utilities
require_once '../database.php'; // Your database connection file

header('Content-Type: application/json');

// Ensure this is a POST request
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['success' => false, 'message' => 'Invalid request method']);
    exit();
}

// Check for the session token (or use your authentication method)
if (!isset($_POST['session_token'])) {
    echo json_encode(['success' => false, 'message' => 'No session token provided']);
    exit();
}

$session_token = $_POST['session_token'];

// Function to authenticate the session token and get the user ID
function authenticate_session($session_token) {
    global $conn; // Use the global $conn from database.php
    $query = "SELECT user_id FROM user_register WHERE session_token = ?";
    $stmt = $conn->prepare($query);
    if ($stmt === false) {
        return false;
    }
    $stmt->bind_param("s", $session_token);
    $stmt->execute();
    $stmt->bind_result($user_id);
    $stmt->fetch();
    $stmt->close();
    return $user_id ? $user_id : false;
}

// Authenticate the session token
$user_id = authenticate_session($session_token);
if (!$user_id) {
    echo json_encode(['success' => false, 'message' => 'Invalid session token']);
    exit();
}

// Check if workout_id is provided
if (!isset($_POST['workout_id'])) {
    echo json_encode(['success' => false, 'message' => 'Workout ID not provided']);
    exit();
}

$workout_id = $_POST['workout_id'];

// Prepare the SQL query to delete the workout
$query = "DELETE FROM workouts WHERE workout_id = ? AND user_id = ?";
$stmt = $conn->prepare($query);

if ($stmt === false) {
    echo json_encode(['success' => false, 'message' => 'Failed to prepare the statement']);
    exit();
}

// Bind the parameters and execute the query
$stmt->bind_param('ii', $workout_id, $user_id);

if ($stmt->execute()) {
    if ($stmt->affected_rows > 0) {
        echo json_encode(['success' => true, 'message' => 'Workout deleted successfully']);
    } else {
        echo json_encode(['success' => false, 'message' => 'No workout found or you don\'t have permission to delete this workout']);
    }
} else {
    echo json_encode(['success' => false, 'message' => 'Error executing query']);
}

$stmt->close();
$conn->close();
?>
