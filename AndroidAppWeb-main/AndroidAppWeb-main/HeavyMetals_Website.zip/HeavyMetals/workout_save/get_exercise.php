<?php
require '../database.php';

// Enable error reporting for debugging (remove this in production)
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Set the response header to JSON
header('Content-Type: application/json');

// Check if workout_id and session_token are provided
if (!isset($_GET['session_token']) || !isset($_GET['workout_id'])) {
    echo json_encode(["success" => false, "message" => "Missing session_token or workout_id."]);
    exit;
}

// Get session token and workout_id from the request
$session_token = $_GET['session_token'];
$workout_id = $_GET['workout_id'];

// Function to verify the session token
function verifySessionToken($session_token) {
    global $conn;
    $sql = "SELECT COUNT(*) FROM user_register WHERE session_token = ?";
    $stmt = $conn->prepare($sql);
    if (!$stmt) {
        return false;
    }
    $stmt->bind_param('s', $session_token);
    $stmt->execute();
    $stmt->bind_result($count);
    $stmt->fetch();
    $stmt->close();
    
    return $count > 0; // Return true if the session token is valid
}

// Verify the session token
if (!verifySessionToken($session_token)) {
    echo json_encode(["success" => false, "message" => "Invalid session token."]);
    exit;
}

// Fetch exercises for the workout using workout_id
$sql = "SELECT exercise_id, exercise_name, sets, reps, is_done FROM exercises WHERE workout_id = ?";
$stmt = $conn->prepare($sql);
if (!$stmt) {
    echo json_encode(["success" => false, "message" => "Failed to prepare statement."]);
    exit;
}

// Bind the workout_id and execute the query
$stmt->bind_param('i', $workout_id);
if (!$stmt->execute()) {
    echo json_encode(["success" => false, "message" => "Failed to execute query."]);
    exit;
}

$result = $stmt->get_result();
$exercises = [];

// Fetch and structure the exercise data
if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $exercises[] = [
            'exercise_id' => $row['exercise_id'],
            'exercise_name' => $row['exercise_name'],
            'sets' => $row['sets'],
            'reps' => $row['reps'],
            'is_done' => $row['is_done']
        ];
    }
}

// Calculate the total number of exercises (exercise count)
$exercise_count = count($exercises);

// Return the structured data as JSON
echo json_encode([
    "success" => true,
    "exercise_count" => $exercise_count,  // Include the exercise count
    "exercises" => $exercises
]);

// Close the statement and connection
$stmt->close();
$conn->close();
?>
