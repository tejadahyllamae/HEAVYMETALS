<?php
header('Content-Type: application/json');
require '../database.php'; // Include your database connection

// Get POST data (Make sure you get the session_token here before using it)
$session_token = $_POST['session_token'] ?? '';
$workout_name = $_POST['workout_name'] ?? '';

// Log received session_token for debugging
error_log("Received session_token: " . $session_token);

// Validate input
if (empty($session_token) || empty($workout_name)) {
    echo json_encode(["success" => 0, "message" => "Session token and workout name are required."]);
    exit;
}

// Verify session token and get user ID
$stmt = $conn->prepare("SELECT user_id FROM user_register WHERE session_token = ?");
$stmt->bind_param("s", $session_token);
$stmt->execute();
$stmt->store_result();
$stmt->bind_result($user_id);
$stmt->fetch();

if ($stmt->num_rows === 0) {
    echo json_encode(["success" => 0, "message" => "Invalid session token."]);
    exit;
}

$stmt->close();

// Insert the workout into the workouts table
$insertStmt = $conn->prepare("INSERT INTO workouts (user_id, workout_name) VALUES (?, ?)");
$insertStmt->bind_param("is", $user_id, $workout_name);

if ($insertStmt->execute()) {
    $workout_id = $insertStmt->insert_id;
    error_log("Workout created successfully with ID: " . $workout_id);
    echo json_encode([
        "success" => 1,
        "message" => "Workout added successfully!",
        "workout_id" => $workout_id
    ]);
} else {
    error_log("Database error: " . $insertStmt->error);
    echo json_encode(["success" => 0, "message" => "Error adding workout: " . $insertStmt->error]);
}

$insertStmt->close();
$conn->close();
?>
