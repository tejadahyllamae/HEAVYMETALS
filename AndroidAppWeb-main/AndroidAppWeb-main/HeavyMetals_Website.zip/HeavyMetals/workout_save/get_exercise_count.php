<?php
header('Content-Type: application/json');

// Include database connection
require_once '../database.php';

if ($_SERVER['REQUEST_METHOD'] == 'GET') {
    $session_token = $_GET['session_token'];
    $workout_id = $_GET['workout_id'];

    // Verify session token
    $user_id = verifySessionToken($session_token, $conn);
    if ($user_id === false) {
        echo json_encode(['success' => false, 'message' => 'Invalid session token']);
        exit();
    }

    // Query to count the number of exercises for the given workout ID
    $sql = "SELECT COUNT(*) as exercise_count FROM exercises WHERE workout_id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param('i', $workout_id);
    $stmt->execute();
    $result = $stmt->get_result();
    $row = $result->fetch_assoc();

    $exercise_count = $row['exercise_count'];

    // Return the count in JSON format
    echo json_encode([
        'success' => true,
        'exerciseCount' => $exercise_count
    ]);
}

// Function to verify the session token
function verifySessionToken($token, $conn) {
    $sql = "SELECT user_id FROM users WHERE session_token = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param('s', $token);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
        return $row['user_id'];
    } else {
        return false;
    }
}
?>
