<?php
require '../database.php';

// Enable error reporting for debugging (disable in production)
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Check if session_token and workout_id are provided
if (!isset($_GET['session_token']) || !isset($_GET['workout_id'])) {
    echo json_encode(["success" => false, "message" => "Missing parameters."]);
    exit;
}

// Get data from GET request
$session_token = $_GET['session_token'];
$workout_id = $_GET['workout_id'];

// Validate session token and workout_id (optional, for better security)
if (!is_numeric($workout_id) || !is_string($session_token)) {
    echo json_encode(["success" => false, "message" => "Invalid input."]);
    exit;
}

// Verify session token and get user ID (optional)
function verifySessionToken($session_token) {
    global $conn;
    $sql = "SELECT user_id FROM user_register WHERE session_token = ?";
    $stmt = $conn->prepare($sql);
    if (!$stmt) {
        return false;
    }
    $stmt->bind_param('s', $session_token);
    $stmt->execute();
    $stmt->bind_result($user_id);
    $stmt->fetch();
    $stmt->close();
    
    return $user_id ? $user_id : false; // Return user_id if the session token is valid
}

$user_id = verifySessionToken($session_token);
if (!$user_id) {
    echo json_encode(["success" => false, "message" => "Invalid session token."]);
    exit;
}

// Fetch exercises from the database
$sql = "SELECT exercise_id, is_done, exercise_name, reps, sets FROM exercises WHERE workout_id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param('i', $workout_id);
$stmt->execute();
$result = $stmt->get_result();

$exercises = [];
while ($row = $result->fetch_assoc()) {
    $exercises[] = [
        "exercise_id" => $row['exercise_id'],
        "is_done" => $row['is_done'] == 1 ? true : false,  // Convert 0/1 to true/false
        "exercise_name" => $row['exercise_name'],
        "reps" => $row['reps'],
        "sets" => $row['sets']
    ];
}
$stmt->close();

echo json_encode(["success" => true, "exercises" => $exercises]);

$conn->close();
?>
