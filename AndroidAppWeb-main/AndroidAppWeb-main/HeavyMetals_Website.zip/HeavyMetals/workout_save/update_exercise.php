<?php
require '../database.php';

// Enable error reporting for debugging (disable in production)
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Check if session_token, workout_id, and exercises are provided
if (!isset($_POST['session_token']) || !isset($_POST['workout_id']) || !isset($_POST['exercises'])) {
    echo json_encode(["success" => false, "message" => "Missing parameters."]);
    exit;
}

// Get data from POST request
$session_token = $_POST['session_token'];
$workout_id = $_POST['workout_id'];
$exercises = json_decode($_POST['exercises'], true); // Decoding JSON array of exercises

// Handle JSON decode errors
if ($exercises === null && json_last_error() !== JSON_ERROR_NONE) {
    echo json_encode(["success" => false, "message" => "Invalid JSON in exercises data."]);
    exit;
}

// Validate session token and workout_id (optional, for better security)
if (!is_numeric($workout_id) || !is_string($session_token)) {
    echo json_encode(["success" => false, "message" => "Invalid input."]);
    exit;
}

// Verify session token and get user ID (optional)
function verifySessionToken($session_token) {
    global $conn;
    $sql = "SELECT user_id FROM user_register WHERE session_token = ?";
    $stmt = $conn->prepare($sql);
    if (!$stmt) {
        return false;
    }
    $stmt->bind_param('s', $session_token);
    $stmt->execute();
    $stmt->bind_result($user_id);
    $stmt->fetch();
    $stmt->close();
    
    return $user_id ? $user_id : false; // Return user_id if the session token is valid
}

$user_id = verifySessionToken($session_token);
if (!$user_id) {
    echo json_encode(["success" => false, "message" => "Invalid session token."]);
    exit;
}

// Update exercises
foreach ($exercises as $exercise) {
    if (!isset($exercise['exercise_id']) || !isset($exercise['is_done'])) {
        echo json_encode(["success" => false, "message" => "Invalid exercise data."]);
        exit;
    }

    $exercise_id = $exercise['exercise_id'];
    // Convert boolean 'is_done' to 1 (true) or 0 (false)
    $is_done = $exercise['is_done'] ? 1 : 0;

    // Update each exercise's status in the database
    $sql = "UPDATE exercises SET is_done = ? WHERE exercise_id = ? AND workout_id = ?";
    $stmt = $conn->prepare($sql);
    if (!$stmt) {
        echo json_encode(["success" => false, "message" => "Failed to prepare statement."]);
        exit;
    }
    $stmt->bind_param('iii', $is_done, $exercise_id, $workout_id);
    if (!$stmt->execute()) {
        echo json_encode(["success" => false, "message" => "Failed to update exercise with ID $exercise_id."]);
        exit;
    }
    $stmt->close();
}

echo json_encode(["success" => true, "message" => "Exercises updated successfully."]);

$conn->close();
?>
