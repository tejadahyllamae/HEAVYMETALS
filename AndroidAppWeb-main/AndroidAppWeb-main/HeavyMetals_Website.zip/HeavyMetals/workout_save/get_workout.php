<?php
require '../database.php';

// Enable error reporting for debugging (disable in production)
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Check if session_token is provided
if (!isset($_GET['session_token'])) {
    echo json_encode(["success" => false, "message" => "Missing session_token."]);
    exit;
}

// Get session token from the request
$session_token = $_GET['session_token'];

// Function to verify the session token and get the user ID
function verifySessionToken($session_token) {
    global $conn;
    
    try {
        // Query to fetch user_id using the session_token from user_register table
        $sql = "SELECT user_id FROM user_register WHERE session_token = ?";
        $stmt = $conn->prepare($sql);
        if (!$stmt) {
            throw new Exception("Failed to prepare statement.");
        }
        $stmt->bind_param('s', $session_token);
        $stmt->execute();
        $stmt->bind_result($user_id);
        $stmt->fetch();
        $stmt->close();
        
        return $user_id ? $user_id : false; // Return user_id if the session token is valid
    } catch (Exception $e) {
        echo json_encode(["success" => false, "message" => $e->getMessage()]);
        exit;
    }
}

// Verify the session token and get the user ID
$user_id = verifySessionToken($session_token);
if (!$user_id) {
    echo json_encode(["success" => false, "message" => "Invalid session token."]);
    exit;
}

try {
    // Fetch workouts for the user using the user_id from the session token
    $sql = "SELECT workout_id, workout_name FROM workouts WHERE user_id = ?";
    $stmt = $conn->prepare($sql);
    if (!$stmt) {
        throw new Exception("Failed to prepare statement.");
    }

    // Bind the user_id and execute the query
    $stmt->bind_param('i', $user_id);
    if (!$stmt->execute()) {
        throw new Exception("Failed to execute query.");
    }

    $result = $stmt->get_result();
    $workouts = [];

    if ($result->num_rows > 0) {
        // Loop through the results and construct the workout data
        while ($row = $result->fetch_assoc()) {
            $workouts[] = [
                'workout_id' => $row['workout_id'],
                'workout_name' => $row['workout_name']
            ];
        }
    }

    // Log the number of workouts fetched for debugging
    error_log("Number of workouts fetched: " . count($workouts));

    // Return the workouts as a JSON response
    echo json_encode(["success" => true, "workouts" => $workouts]);

    // Close the statement and connection
    $stmt->close();
    $conn->close();

} catch (Exception $e) {
    echo json_encode(["success" => false, "message" => $e->getMessage()]);
    exit;
}
?>
