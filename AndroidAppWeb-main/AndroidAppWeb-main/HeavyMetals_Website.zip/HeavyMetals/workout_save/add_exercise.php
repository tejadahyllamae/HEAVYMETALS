<?php

require '../database.php';

// Get the raw POST data as JSON
$data = file_get_contents('php://input');
$request = json_decode($data, true);

// Get workout_id and exercises from the request
$workout_id = $request['workout_id'] ?? null;
$exercises = $request['exercises'] ?? [];

// Check if data is valid
if (empty($workout_id) || empty($exercises)) {
    http_response_code(400);
    echo json_encode(["error" => "Invalid data provided"]);
    exit();
}

// Verify that the workout exists in the workouts table
$workoutCheckQuery = $conn->prepare("SELECT * FROM workouts WHERE workout_id = ?");
$workoutCheckQuery->bind_param("i", $workout_id);
$workoutCheckQuery->execute();
$workoutResult = $workoutCheckQuery->get_result();

if ($workoutResult->num_rows === 0) {
    http_response_code(400);
    echo json_encode(["error" => "Workout does not exist"]);
    exit();
}
$workoutCheckQuery->close();

// Prepare the query to insert each exercise into the exercises table
$insertExerciseQuery = $conn->prepare("INSERT INTO exercises (workout_id, exercise_name, sets, reps, exercise_list_id) VALUES (?, ?, ?, ?, ?)");

foreach ($exercises as $exercise) {
    $exercise_name = $exercise['exercise_name'];
    $sets = $exercise['sets'];
    $reps = $exercise['reps'];
    
    // Get the exercise_list_id from the exercises_list table based on exercise name
    $exerciseListQuery = $conn->prepare("SELECT id FROM exercises_list WHERE exercise_name = ?");
    $exerciseListQuery->bind_param("s", $exercise_name);
    $exerciseListQuery->execute();
    $exerciseListResult = $exerciseListQuery->get_result();
    
    if ($exerciseListResult->num_rows > 0) {
        $exercise_list_id = $exerciseListResult->fetch_assoc()['id'];
        $exerciseListQuery->close();
    } else {
        // If no matching exercise is found, set exercise_list_id to NULL
        $exercise_list_id = null;
        $exerciseListQuery->close();
    }

    // Now bind the parameters and insert, allowing exercise_list_id to be NULL
    if (!empty($exercise_name) && !empty($sets) && !empty($reps)) {
        $insertExerciseQuery->bind_param("isiii", $workout_id, $exercise_name, $sets, $reps, $exercise_list_id);
        $insertExerciseQuery->execute();
    }
}

$insertExerciseQuery->close();

// Respond with success message
http_response_code(200);
echo json_encode(["success" => true, "message" => "Exercises saved successfully"]);

$conn->close();
?>
