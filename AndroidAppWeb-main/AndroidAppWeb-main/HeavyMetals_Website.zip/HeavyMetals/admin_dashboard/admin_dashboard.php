<?php
session_start();
if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
    header("Location: admin_login.php");
    exit;
}
require '../database.php';  // MySQLi connection is established in database.php

// Get the current year and month
$currentMonth = date('m');
$currentYear = date('Y');

try {
    // Prepare the SQL statement to count the accounts created this month
    $sql = "SELECT COUNT(*) AS accounts_created FROM user_register WHERE MONTH(created_at) = ? AND YEAR(created_at) = ?";
    $stmt = $conn->prepare($sql);

    // Bind the parameters and execute the statement
    $stmt->bind_param('ii', $currentMonth, $currentYear);
    $stmt->execute();

    // Get the result
    $result = $stmt->get_result();
    $row = $result->fetch_assoc();

    // Output the number of accounts created this month
    $accountsCreatedThisMonth = $row['accounts_created'];
    echo "Accounts created this month: " . $accountsCreatedThisMonth;

    // Close the statement
    $stmt->close();
} catch (Exception $e) {
    // Handle any errors during the execution
    echo "Error: " . $e->getMessage();
}
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard</title>
    <link rel="stylesheet" href="admin_dashboard.css">
</head>
<body>
    <div class="user-side_container">
        <header class="navbar">
            <div class="logo">
                <img src="icons/logo.png" alt="Heavy Metals Logo">
                <p>Heavy Metals</p>
            </div>
            
            <nav>
                <ul>
                    <li><a href="admin_dashboard.php" class="dashboard">Dashboard</a></li>
                    <li><a href="admin_user.php" class="edit_users">Edit Users</a></li>
                    <li><a href="admin_add_exercise.php" class="add_exercise1">Add Exercise</a></li>
                    <li><a href="logout.php" class="logout">Logout</a></li>
                </ul>
            </nav>
        </header>
    
        <div class="profile-admin container">
            <div class="profile-admin-content">
                <img src="icons/profile-ic.png" alt="Profile Icon">
                <div class="profile-text">
                    <h4>Hello Admin</h4>
                    <p>Dashboard overview</p>
                </div>
            </div>
        </div>

        <!-- Chart Containers -->
        <div class="chart-container">
            <div class="card" id="card1">
                <div class="card-header">
                    <h2>ACCOUNTS</h2>
                    <button class="last-month-btn">Last Month</button>
                </div>
                
                <div class="card-body">
                    <div class="card-stat">
                        <!-- Display the dynamically fetched accounts created this month -->
                        <h3><?php echo $accountsCreatedThisMonth; ?></h3>
                        <p>Accounts made this month</p>
                    </div>
                    <div class="btn-manage">
                        <button class="manage-account-btn">MANAGE ACCOUNT</button>
                    </div>    
                </div>
                
                <!-- Bar Chart Container -->
                <div class="barchart1-container">
                    <canvas id="barchart1"></canvas>
                </div>
                
                <!-- Line Chart Container -->
                <div class="linechart1-container">
                    <div class="linechart1-body">
                        <canvas id="linechart1"></canvas>
                    </div>
                <p class="details1">Active Accounts</p>
                <h1 class="percent"> 67% </h1>
                <p class="details">are still active compare to the created accounts</p>
                </div>
            </div>
             <!--Most Used Exercise Section-->
        <section class="exercise-stats-section">
            <div class="card" id="card2">
                <div class="card-exercise-stats">
                    <h2>Most Used Exercise</h2>
                    <p>PUSH UPS</p>
                    <h1>72%</h1>
                    <p>of users uses this exercise</p>
                </div>

                <div class="image-container">
                    <img src="icons/profile-ic.png" alt="Image-Here">
                </div>
            <hr>
                <div class="card-exercise-stats">
                    <h1>64%</h1>
                    <p>Kettle Bell Swing</p><br>
                    <h1>42%</h1>
                    <p>Deadlift</p>
                </div>
            </div
            
        <!--Current Exercises-->
            <div class="card" id="card3">
                <div class="card-exercise-stats">
                    <h2>Current Exercises</h2>
                    <p>PUSH UPS</p>
                    <h1>72%</h1>
                    
                    <div class="addBtn-exercise">
                        <button class="add-exercise-btn">Add Exercise</button>
                    </div> 
                </div>

                </div>
            </section>
            
        </div>
        </div>
    </div>
    
    <!-- Include Chart.js and your graph script -->
    <script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.4/dist/chart.umd.min.js"></script>
    <script src="linegraph.js"></script>
</body>
</html>
