<?php
session_start();
if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
    header("Location: admin_login.php");
    exit;
}

require '../database.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $exercise_name = $_POST['exercise_name'] ?? '';
    $category = $_POST['category'] ?? ''; 
    $image_url = $_POST['image_url'] ?? '';

    // Basic input validation
    if (!empty($exercise_name) && !empty($category) && !empty($image_url)) {
        // Ensure category is one of the accepted values
        $allowed_categories = ['Upper Body', 'Lower Body', 'Core', 'Arms', 'Legs'];
        if (!in_array($category, $allowed_categories)) {
            $error_message = "Invalid category selected.";
        } else {
            // Check if exercise already exists
            $stmt = $conn->prepare("SELECT COUNT(*) FROM exercises_list WHERE exercise_name = ?");
            $stmt->bind_param("s", $exercise_name);
            $stmt->execute();
            $stmt->bind_result($exercise_count);
            $stmt->fetch();
            $stmt->close();

            if ($exercise_count > 0) {
                // Exercise already exists
                $error_message = "Exercise with this name already exists. Please add a new one.";
            } else {
                // Prepare the SQL statement to insert a new exercise
                $stmt = $conn->prepare("INSERT INTO exercises_list (exercise_name, category, image_url) VALUES (?, ?, ?)");
                $stmt->bind_param("sss", $exercise_name, $category, $image_url);

                // Execute the statement and check the result
                if ($stmt->execute()) {
                    $success_message = "Exercise added successfully.";
                } else {
                    $error_message = "Failed to add exercise.";
                }

                $stmt->close();
            }
        }
    } else {
        $error_message = "All fields are required.";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard</title>
    <link rel="stylesheet" href="admin_add_exercise.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Konkhmer+Sleokchher&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.6.0/css/all.min.css">
</head>
<body>

<div class="dashboard_container">
    <header class="navbar">
        <div class="logo">
            <img src="icons/logo.png" alt="Heavy Metals Logo">
            <p>Heavy Metals</p>
        </div>
        <nav>
            <ul>
                    <li><a href="admin_chart.php" class="add_exercise1">Dashboard</a></li>
                    <li><a href="admin_user.php" class="edit_users">Edit Users</a></li>
                    <li><a href="admin_add_exercise.php" class="add_exercise1">Add Exercise</a></li>
                    <li><a href="logout.php" class="logout">Logout</a></li>
            </ul>
        </nav>
    </header>

    <div class="add_exercise_container">
        <div class="add_exercise">
            <h2>Add New Exercise</h2>

            <?php if (isset($success_message)): ?>
                <p class="success"><?php echo $success_message; ?></p>
            <?php endif; ?>
            <?php if (isset($error_message)): ?>
                <p class="error"><?php echo $error_message; ?></p>
            <?php endif; ?>

            <form method="POST" action="">
                <label>Exercise Name: <input type="text" name="exercise_name" required placeholder="Type here"></label><br>
                <label>Category:</label>
                <select name="category" required>
                    <option value="">Select Category</option>
                    <option value="Upper Body">Upper Body</option>
                    <option value="Lower Body">Lower Body</option>
                    <option value="Core">Core</option>
                    <option value="Arms">Arms</option>
                    <option value="Legs">Legs</option>
                </select><br>
                
                <div class="icon-btn-container">
                    <label>Image URL:</label>
                        <div class="input-with-icon">
                            <input type="text" name="image_url" placeholder="Paste image URL">
                            <button class="icon-btn"><i class="fa-solid fa-desktop"></i></button>
                        </div><br>
                </div>
                    <button type="submit" id="add-exercise-btn">Add Exercise</button>
            </form>
        </div>

        <div class="current_exercise">
    <div class="header-container">
    <div class="exercise-header">
        <h2>Current Exercises</h2>
    </div>

    <div class="dropdown">
        <!-- Dropdown toggle button -->
        <button onclick="toggleDropdown()" class="dropbtn">Sort</button>

        <!-- Dropdown menu content -->
        <div id="myDropdown" class="dropdown-content">
            <p onclick="sortTable(0, 'asc')">Sort A-Z</p>
            <p onclick="sortTable(0, 'desc')">Sort Z-A</p>
            <p onclick="sortByDate('desc')">Sort by Latest Added</p>
            <p onclick="sortByDate('asc')">Sort by Oldest Added</p>
        </div>

        <!-- Filter by category select box -->
        <select id="sort-category" name="category" required onchange="filterByCategory()">
            <option value="">Category</option>
            <option value="Upper Body">Upper Body</option>
            <option value="Lower Body">Lower Body</option>
            <option value="Core">Core</option>
            <option value="Arms">Arms</option>
            <option value="Legs">Legs</option>
        </select>
        
        <!-- Search input for filtering -->
        <input type="text" placeholder="Search.." id="myInput" onkeyup="filterFunction()">
    </div>
</div>


    <table class="exercise-table" id="exerciseTable">
        <tbody>
            <?php
            $result = $conn->query("SELECT * FROM exercises_list ORDER BY created_at DESC"); // Show all exercises
            while ($row = $result->fetch_assoc()) {
                echo "<tr data-created-at='{$row['created_at']}' data-category='{$row['category']}'>
                        <td>{$row['exercise_name']}</td>
                        <td>{$row['category']}</td>
                        <td><a href='#' class='delete-exercise' data-id='{$row['id']}'>Delete</a></td>
                      </tr>";
            }
            $result->close();
            $conn->close();
            ?>
        </tbody>
    </table>
</div>

<script>
// Handle delete link click
document.querySelectorAll('.delete-exercise').forEach(function(deleteLink) {
    deleteLink.addEventListener('click', function(event) {
        event.preventDefault();
        var exerciseId = this.getAttribute('data-id');

        // Show confirmation prompt
        var confirmation = confirm('Are you sure you want to delete this exercise?');
        if (confirmation) {
            // Prompt for password
            var password = prompt('Please enter your password to confirm:');
            if (password) {
                // Send AJAX request to server with password and exercise ID
                deleteExercise(exerciseId, password);
            } else {
                alert('Password is required to delete an exercise.');
            }
        }
    });
});

// Function to send delete request
function deleteExercise(exerciseId, password) {
    var xhr = new XMLHttpRequest();
    xhr.open('POST', 'delete_exercise.php', true);
    xhr.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
    xhr.onreadystatechange = function() {
        if (xhr.readyState === 4 && xhr.status === 200) {
            // Handle response from server
            var response = JSON.parse(xhr.responseText);
            if (response.success) {
                alert('Exercise deleted successfully.');
                location.reload(); // Reload the page to update the exercise list
            } else {
                alert('Failed to delete exercise: ' + response.message);
            }
        }
    };
    // Send request with exercise ID and password
    xhr.send('id=' + exerciseId + '&password=' + encodeURIComponent(password));
}

       // Function to toggle dropdown visibility
function toggleDropdown() {
    var dropdown = document.getElementById("myDropdown");
    dropdown.classList.toggle("show");
}

// Hide the dropdown if the user clicks outside of it
window.onclick = function(event) {
    if (!event.target.matches('.dropbtn')) {
        var dropdowns = document.getElementsByClassName("dropdown-content");
        for (var i = 0; i < dropdowns.length; i++) {
            var openDropdown = dropdowns[i];
            if (openDropdown.classList.contains('show')) {
                openDropdown.classList.remove('show');
            }
        }
    }
}

// Sort the table rows by exercise name (case-insensitive)
function sortTable(colIndex, order) {
    var table, rows, switching, i, x, y, shouldSwitch;
    table = document.getElementById("exerciseTable");
    switching = true;

    while (switching) {
        switching = false;
        rows = table.getElementsByTagName("TR");

        for (i = 0; i < rows.length - 1; i++) {
            shouldSwitch = false;
            x = rows[i].getElementsByTagName("TD")[colIndex].textContent.toLowerCase(); // Convert to lowercase
            y = rows[i + 1].getElementsByTagName("TD")[colIndex].textContent.toLowerCase(); // Convert to lowercase

            if (order === 'asc') {
                if (x > y) {
                    shouldSwitch = true;
                    break;
                }
            } else if (order === 'desc') {
                if (x < y) {
                    shouldSwitch = true;
                    break;
                }
            }
        }

        if (shouldSwitch) {
            rows[i].parentNode.insertBefore(rows[i + 1], rows[i]);
            switching = true;
        }
    }
}

// Sort the table rows by created_at date
function sortByDate(order) {
    var table, rows, switching, i, x, y, shouldSwitch;
    table = document.getElementById("exerciseTable");
    switching = true;

    while (switching) {
        switching = false;
        rows = table.getElementsByTagName("TR");

        for (i = 0; i < rows.length - 1; i++) {
            shouldSwitch = false;
            x = rows[i].getAttribute("data-created-at");
            y = rows[i + 1].getAttribute("data-created-at");

            if (order === 'asc') { // Sort by oldest (ascending)
                if (new Date(x) > new Date(y)) {
                    shouldSwitch = true;
                    break;
                }
            } else if (order === 'desc') { // Sort by newest (descending)
                if (new Date(x) < new Date(y)) {
                    shouldSwitch = true;
                    break;
                }
            }
        }

        if (shouldSwitch) {
            rows[i].parentNode.insertBefore(rows[i + 1], rows[i]);
            switching = true;
        }
    }
}

// Filter exercises based on category
function filterByCategory() {
    var selectCategory = document.getElementById("sort-category").value;
    var table = document.getElementById("exerciseTable");
    var tr = table.getElementsByTagName("tr");

    for (var i = 0; i < tr.length; i++) {
        var category = tr[i].getAttribute("data-category");
        if (selectCategory === "" || category === selectCategory) {
            tr[i].style.display = "";
        } else {
            tr[i].style.display = "none";
        }
    }
}




        // Search the exercise table by exercise name
        function filterFunction() {
            var input, filter, table, tr, td, i, txtValue;
            input = document.getElementById("myInput");
            filter = input.value.toUpperCase();
            table = document.getElementById("exerciseTable");
            tr = table.getElementsByTagName("tr");

            for (i = 0; i < tr.length; i++) {
                td = tr[i].getElementsByTagName("td")[0]; 
                if (td) {
                    txtValue = td.textContent || td.innerText;
                    if (txtValue.toUpperCase().indexOf(filter) > -1) {
                        tr[i].style.display = "";
                    } else {
                        tr[i].style.display = "none";
                    }
                }
            }
        }

        // Filter exercises based on category
        function filterByCategory() {
            var selectCategory = document.getElementById("sort-category").value;
            var table = document.getElementById("exerciseTable");
            var tr = table.getElementsByTagName("tr");

            for (var i = 0; i < tr.length; i++) {
                var category = tr[i].getAttribute("data-category");
                if (selectCategory === "" || category === selectCategory) {
                    tr[i].style.display = "";
                } else {
                    tr[i].style.display = "none";
                }
            }
        }
        </script>
    </div>
</div>
</body>
</html>
