<?php
session_start();
if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
    header("Location: admin_login.php");
    exit;
}
require '../database.php';  // MySQLi connection is established in database.php

// Get the current month and year
$currentMonth = date('m');
$currentYear = date('Y');

// Initialize default counts
$accountsCreatedThisMonth = 0;
$exerciseCount = 0;
$activeAccountsCount = 0;  // Initialize active accounts count

// Initialize default counts for each month (January to December)
$accountsPerMonth = array_fill(1, 12, 0); // Array with 12 zeros for each month

try {
    // Prepare the SQL statement to count the accounts created this month
    $sql = "SELECT COUNT(*) AS accounts_created FROM user_register WHERE MONTH(created_at) = ? AND YEAR(created_at) = ?";
    $stmt = $conn->prepare($sql);

    // Bind the parameters and execute the statement
    $stmt->bind_param('ii', $currentMonth, $currentYear);
    $stmt->execute();

    // Get the result
    $result = $stmt->get_result();
    $row = $result->fetch_assoc();

    // Output the number of accounts created this month
    if ($row && isset($row['accounts_created'])) {
        $accountsCreatedThisMonth = $row['accounts_created'];
    }

    // Close the statement
    $stmt->close();
} catch (Exception $e) {
    // Handle any errors during the execution
    echo "Error fetching accounts: " . $e->getMessage();
}

try {
    // Prepare the SQL statement to count the accounts created for each month in the current year
    $sql = "SELECT MONTH(created_at) AS month, COUNT(*) AS accounts_created 
            FROM user_register 
            WHERE YEAR(created_at) = ?
            GROUP BY MONTH(created_at)";
    $stmt = $conn->prepare($sql);

    // Bind the current year and execute the statement
    $stmt->bind_param('i', $currentYear);
    $stmt->execute();

    // Get the result
    $result = $stmt->get_result();

    // Fill the array with the data for each month
    while ($row = $result->fetch_assoc()) {
        $month = (int) $row['month'];
        $accountsPerMonth[$month] = (int) $row['accounts_created'];
    }

    // Close the statement
    $stmt->close();
} catch (Exception $e) {
    // Handle any errors during the execution
    echo "Error fetching accounts by month: " . $e->getMessage();
}

try {
    // Prepare the SQL statement to count the exercises, counting all existing exercises
    $sql = "SELECT COUNT(*) AS exercise_count FROM exercises_list";  // Replace exercise_table with your actual table name
    $stmt = $conn->prepare($sql);

    // Execute the statement
    $stmt->execute();

    // Get the result
    $result = $stmt->get_result();
    $row = $result->fetch_assoc();

    // Output the number of exercises
    if ($row && isset($row['exercise_count'])) {
        $exerciseCount = $row['exercise_count'];
    }

    // Close the statement
    $stmt->close();
} catch (Exception $e) {
    // Handle any errors during the execution
    echo "Error fetching exercises: " . $e->getMessage();
}

try {
    // Prepare the SQL statement to count active accounts (where session_token is not null or empty)
    $sql = "SELECT COUNT(*) AS active_accounts FROM user_register WHERE session_token IS NOT NULL AND session_token != ''";
    $stmt = $conn->prepare($sql);

    // Execute the statement
    $stmt->execute();

    // Get the result
    $result = $stmt->get_result();
    $row = $result->fetch_assoc();

    // Output the number of active accounts
    if ($row && isset($row['active_accounts'])) {
        $activeAccountsCount = $row['active_accounts'];
    }

    // Close the statement
    $stmt->close();
} catch (Exception $e) {
    // Handle any errors during the execution
    echo "Error fetching active accounts: " . $e->getMessage();
}
?>







<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard</title>
    <link rel="stylesheet" href="admin_chart.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Konkhmer+Sleokchher&display=swap" rel="stylesheet">
</head>
<body>
    <div class="user-side_container">
        <header class="navbar">
            <div class="logo">
                <img src="icons/logo.png" alt="Heavy Metals Logo">
                <p>Heavy Metals</p>
            </div>
            
            <nav>
                <ul>
                    <li><a href="admin_chart.php" class="dashboard">Dashboard</a></li>
                    <li><a href="admin_user.php" class="edit_users">Edit Users</a></li>
                    <li><a href="admin_add_exercise.php" class="add_exercise1">Add Exercise</a></li>
                    <li><a href="logout.php" class="logout">Logout</a></li>
                </ul>
            </nav>
        </header>
    
        <div class="profile-admin container">
            <div class="profile-admin-content">
                <img src="icons/profile-ic.png" alt="Profile Icon">
                <div class="profile-text">
                    <h4>Hello Admin</h4>
                    <p>Dashboard overview</p>
                </div>
            </div>
        </div>

        <!-- Chart Containers -->
        <div class="chart-container">
            <div class="card" id="card1">
                <div class="header-container">
                    <div class="card-header">
                        <h2>ACCOUNTS</h2>
                        <button class="last-month-btn">Last Month</button>
                    </div>

                    <div class="card-body">
                        <div class="card-stat">
                            <!-- Display the dynamically fetched accounts created this month -->
                            <h3><?php echo htmlspecialchars($accountsCreatedThisMonth, ENT_QUOTES, 'UTF-8'); ?></h3>
                            <p>Accounts made this month</p>
                        </div>
                    </div>   
                </div>
                
                <!-- Bar Chart Container -->
                <div class="barchart1-container">
                    <canvas id="barchart1"></canvas>
                </div>
                
                <!-- Line Chart Container for Active Accounts -->
                <div class="linechart1-container">
                    <div class="linechart1-body">
                        <canvas id="linechart1"></canvas>
                    </div>
                    <p class="details1">Active Accounts</p>
                    <!-- Display the number of active accounts dynamically -->
                    <h1 class="percent"><?php echo htmlspecialchars($activeAccountsCount, ENT_QUOTES, 'UTF-8'); ?>%</h1>
                    <p class="details">are still active compared to the created accounts</p>
                </div>

                <div class="btn-manage">
                    <button class="manage-account-btn">MANAGE ACCOUNT</button>
                </div> 
            </div>

             <!-- Most Used Exercise Section -->
            <section class="exercise-stats-section">
                <div class="card" id="card2">
                    <div class="card-exercise-stats">
                        <div class="card2-header">
                            <h2>Most Used Exercise</h2>
                        </div>

                        <div class="most-used-exercise-container">
                            <div class="card-exercise-stats" id="card-exercise1-stats">
                                <h1>72%</h1>
                                <p>of users use this exercise:</p>
                                <p id="exercise1_name">PUSH UPS</p>
                            </div>

                            <div class="card-exercise-stats" id="card-exercise2-stats">
                                <h1>64%</h1>
                                <p>Kettle Bell Swing</p>
                                <h1>42%</h1>
                                <p>Deadlift</p>
                            </div>
                        </div>   

                        <div class="image-container">
                            <img src="icons/exercise of the week.png" alt="Push Ups">
                        </div>
                   </div>
                </div>

                <div class="barchart2-container">
                    <canvas id="barchart2"></canvas>
                </div>

                <div class="card3">
                    <div class="card3-header">
                        <h2>Current Exercises</h2>
                    </div>

                    <div class="exercise-container">
                        <div class="card-exercise-stats" id="card-exercise3-stats">
                            <!-- Dynamically display the fetched number of exercises -->
                            <h1><?php echo htmlspecialchars($exerciseCount, ENT_QUOTES, 'UTF-8'); ?></h1>
                            <p>Latest Added:</p>
                        </div>

                        <div class="btn-manage">
                            <button class="add-exercise-btn">Add Exercise</button>
                        </div> 
                    </div>

                    <div class="latest-added-container">
                        <div class="latest-added-exercise-cards">
                            <div class="exercise-card1">
                                <div class="exercise-img1">
                                    <img src="icons/image (1).png">
                                </div>
                                <div class="info">
                                    <p>Treadmill (Walking)</p>
                                    <p>Cardio</p>
                                </div>
                            </div>

                            <div class="exercise-card1">
                                <div class="exercise-img1">
                                    <img src="icons/image (1).png">
                                </div>
                                <div class="info">
                                    <p>Treadmill (Walking)</p>
                                    <p>Cardio</p>
                                </div>
                            </div>
                        </div>

                        <!-- Second row -->
                        <div class="latest-added-exercise-cards">
                            <div class="exercise-card1">
                                <div class="exercise-img1">
                                    <img src="icons/image (1).png">
                                </div>
                                <div class="info">
                                    <p>Treadmill (Walking)</p>
                                    <p>Cardio</p>
                                </div>
                            </div>

                            <div class="exercise-card1">
                                <div class="exercise-img1">
                                    <img src="icons/image (1).png">
                                </div>
                                <div class="info">
                                    <p>Treadmill (Walking)</p>
                                    <p>Cardio</p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
        </div>
    </div>
    
    <!-- Include Chart.js and your graph script -->
    <script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.4/dist/chart.umd.min.js"></script>
    <script>
    // Pass PHP variables to JavaScript
    const accountsCreatedThisMonth = <?php echo json_encode($accountsCreatedThisMonth); ?>;
    const exerciseCount = <?php echo json_encode($exerciseCount); ?>;
    const accountsPerMonth = <?php echo json_encode(array_values($accountsPerMonth)); ?>;

    // Setup for the monthly bar chart using Chart.js
    const ctx1 = document.getElementById('barchart1').getContext('2d');
    const barChart1 = new Chart(ctx1, {
        type: 'bar',
        data: {
            labels: ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'],
            datasets: [{
                label: 'Accounts Created This Year',
                data: accountsPerMonth,
                backgroundColor: 'rgba(255, 99, 132, 0.2)',
                borderColor: 'rgba(255, 99, 132, 1)',
                borderWidth: 1
            }]
        },
        options: {
            scales: {
                y: {
                    beginAtZero: true,
                    ticks: {
                        stepSize: 1 // Adjust if necessary
                    }
                }
            }
        }
    });

    // Setup for the exercise bar chart
    const ctx2 = document.getElementById('barchart2').getContext('2d');
    const barChart2 = new Chart(ctx2, {
        type: 'bar',
        data: {
            labels: ['Exercises'],
            datasets: [{
                label: 'Current Exercises',
                data: [exerciseCount],
                backgroundColor: 'rgba(54, 162, 235, 0.2)',
                borderColor: 'rgba(54, 162, 235, 1)',
                borderWidth: 1
            }]
        },
        options: {
            scales: {
                y: {
                    beginAtZero: true
                }
            }
        }
    });
</script>

</body>
</html>