const lineCtx = document.getElementById('linechart1').getContext('2d');
const barCtx = document.getElementById('barchart1').getContext('2d');

// Generate month labels dynamically for the current year
function getMonthLabels() {
  return ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];
}

// Fetch dynamic data from the server (replace `data.php` with your PHP file that returns data)
async function fetchDynamicData() {
  try {
    const response = await fetch('data.php'); // Replace with the actual URL of your PHP backend
    const data = await response.json(); // Expecting JSON format from PHP
    return data; // Return the data fetched from the server
  } catch (error) {
    console.error('Error fetching data:', error);
    return { activeAccounts: [], accountsCreated: [] }; // Fallback if error occurs
  }
}

// Create the gradient dynamically based on the canvas height for the line chart
function createLineGradient(ctx) {
  const gradient = ctx.createLinearGradient(0, 0, 0, ctx.canvas.height);
  gradient.addColorStop(0, 'rgba(222, 97, 43, 1)');
  gradient.addColorStop(1, 'rgba(39, 37, 37, 0)');
  return gradient;
}

// Create the line chart
async function createLineChart(ctx) {
  const gradient = createLineGradient(ctx);
  const data = await fetchDynamicData(); // Fetch dynamic data from the server

  new Chart(ctx, {
    type: 'line',
    data: {
      labels: getMonthLabels(),
      datasets: [{
        label: 'Active Accounts',
        data: data.activeAccounts,  // Assuming `activeAccounts` is part of the returned data
        backgroundColor: gradient,
        borderColor: 'rgba(222, 97, 43, 1)',
        borderWidth: 2,
        fill: true
      }]
    },
    options: {
      responsive: true,
      maintainAspectRatio: false,
      scales: {
        y: {
          beginAtZero: true,
          title: {
            display: true,
            text: 'Active Accounts'
          }
        },
        x: {
          title: {
            display: false
          }
        }
      },
      plugins: {
        legend: {
          display: true,
          position: 'top'
        },
        tooltip: {
          enabled: true
        }
      }
    }
  });
}

// Create the bar chart
async function createBarChart(ctx) {
  const data = await fetchDynamicData(); // Fetch dynamic data from the server

  new Chart(ctx, {
    type: 'bar',
    data: {
      labels: getMonthLabels(),
      datasets: [{
        label: 'Accounts Created',
        data: data.accountsCreated,  // Assuming `accountsCreated` is part of the returned data
        backgroundColor: 'rgba(222, 97, 43, 0.8)',  // Solid color for bars
        borderColor: 'rgba(222, 97, 43, 1)',
        borderWidth: 1,
        barThickness: 35,  // Adjust bar thickness for wider bars like in the first image
      }]
    },
    options: {
      responsive: true,
      maintainAspectRatio: false,
      scales: {
        y: {
          beginAtZero: true,
          title: {
            display: true,
            text: 'Accounts'
          }
        },
        x: {
          title: {
            display: false
          }
        }
      },
      plugins: {
        legend: {
          display: true,
          position: 'top'
        },
        tooltip: {
          enabled: true
        }
      }
    }
  });
}

// Initialize both charts
async function initializeCharts() {
  const data = await fetchDynamicData(); // Fetch data once and pass to both charts
  createLineChart(lineCtx, data);  // Pass the data to the line chart
  createBarChart(barCtx, data);  // Pass the same data to the bar chart
}

initializeCharts();  // Call the function to initialize both charts
