<?php
session_start();
require '../database.php';

if (isset($_POST['login'])) {
    $username = $_POST['username'] ?? '';
    $password = $_POST['password'] ?? '';

    // Check if credentials are correct
    if ($username == 'admin' && $password == 'password') {  // Change to actual credentials
        $_SESSION['admin_logged_in'] = true;
        header("Location: admin_chart.php");
        exit;
    } else {
        $error = "Invalid credentials";
    }
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Login</title>
    <link rel="stylesheet" href="admin_login.css">
</head>
<body>
    <div class="main">
        <div class="container">
        <div class="logo">
            <a href="Heavymetals.html">
            <img src="icons/logo.png"> </a>
            <a href="Heavymetals.html"><p>Heavy Metals</p></a>
           
        </div>
        </div>



        <div class="login-container">

            <div class="caption">
                <h2>HEAVY</h2>
                <h3>METALS</h3>
                <p>MANAGE YOUR GYM IN THE PALM OF YOUR HANDS</p>
            </div>


        
            <?php if (isset($error)): ?>
                <p style="color: red;"><?php echo $error; ?></p>
            <?php endif; ?>

            <div class="form-container">
                <form method="POST" action="">
                <input type="text" name="username" placeholder="USERNAME">
                <input type="password" name="password" placeholder="PASSWORD">
                <button type="submit" name="login" class="login-btn">Login</button>
                <hr>
               
                </form>
            </div>
        </div>
    </div>
</body>
</html>
