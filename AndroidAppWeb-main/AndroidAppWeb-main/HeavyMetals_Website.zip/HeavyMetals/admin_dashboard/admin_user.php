<?php
session_start();
if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
    header("Location: admin_login.php");
    exit;
}
require '../database.php';

// SQL query to fetch the required data including phone number, user_id, and session_token
$sql = "SELECT user_id, CONCAT(first_name, ' ', last_name) AS name, email, phone_number, session_token, created_at FROM user_register";

// Execute the query
$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin User</title>
    <link rel="stylesheet" href="admin_user.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Konkhmer+Sleokchher&display=swap" rel="stylesheet">
<script>
    let currentPage = 1;
    let rowsPerPage = 10;  // Default rows per page
    let sortOrder = 'asc';  // Track sorting order (asc/desc)

    // Function to confirm deletion
    function confirmDelete() {
        return confirm('Are you sure you want to delete this user? This action cannot be undone.');
    }

    // Function to change rows per page
    function changeRowsPerPage() {
        const selectedValue = document.getElementById("rowsPerPage").value;
        if (selectedValue === "all") {
            rowsPerPage = document.getElementById("user-table-body").getElementsByTagName("tr").length;  // Show all rows
        } else {
            rowsPerPage = parseInt(selectedValue);  // Set rowsPerPage to the selected value
        }
        currentPage = 1;  // Reset to the first page
        displayTablePage(currentPage);
    }

    // Function to display table rows based on the current page
    function displayTablePage(page) {
        const table = document.getElementById("user-table-body");
        const tr = table.getElementsByTagName("tr");
        const totalRows = tr.length;

        // Calculate start and end row for current page
        const start = (page - 1) * rowsPerPage;
        const end = start + rowsPerPage;

        // Loop through rows and display only the relevant rows for the current page
        for (let i = 0; i < totalRows; i++) {
            if (i >= start && i < end) {
                tr[i].style.display = "";
            } else {
                tr[i].style.display = "none";
            }
        }

        // Update pagination controls
        updatePaginationControls(totalRows);
    }

    // Function to update pagination controls
    function updatePaginationControls(totalRows) {
        const paginationDiv = document.getElementById("pagination-controls");
        paginationDiv.innerHTML = "";  // Clear existing controls

        if (rowsPerPage >= totalRows) return;  // If "Show all" is selected, no pagination is needed

        const totalPages = Math.ceil(totalRows / rowsPerPage);  // Calculate total pages

        // Create Previous button
        if (currentPage > 1) {
            paginationDiv.innerHTML += `<button onclick="prevPage()">Previous</button>`;
        }

        // Create page number buttons
        for (let i = 1; i <= totalPages; i++) {
            if (i === currentPage) {
                paginationDiv.innerHTML += `<button class="active">${i}</button>`;
            } else {
                paginationDiv.innerHTML += `<button onclick="goToPage(${i})">${i}</button>`;
            }
        }

        // Create Next button
        if (currentPage < totalPages) {
            paginationDiv.innerHTML += `<button onclick="nextPage()">Next</button>`;
        }
    }

    // Go to specific page
    function goToPage(page) {
        currentPage = page;
        displayTablePage(page);
    }

    // Go to next page
    function nextPage() {
        currentPage++;
        displayTablePage(currentPage);
    }

    // Go to previous page
    function prevPage() {
        currentPage--;
        displayTablePage(currentPage);
    }

    // Sort table based on column (phone number, status, or user since)
    function sortTable(columnIndex, dataType) {
        const table = document.getElementById("user-table-body");
        const rows = Array.from(table.getElementsByTagName("tr"));
        const compareFunction = (a, b) => {
            let valA = a.getElementsByTagName("td")[columnIndex].innerText;
            let valB = b.getElementsByTagName("td")[columnIndex].innerText;

            if (dataType === 'date') {
                valA = new Date(a.getAttribute('data-created-at'));
                valB = new Date(b.getAttribute('data-created-at'));
            }

            if (sortOrder === 'asc') {
                return valA > valB ? 1 : -1;
            } else {
                return valA < valB ? 1 : -1;
            }
        };

        rows.sort(compareFunction);

        // Reverse sorting order for the next click
        sortOrder = (sortOrder === 'asc') ? 'desc' : 'asc';

        // Rebuild the table body with sorted rows
        rows.forEach(row => table.appendChild(row));

        // Update the header and row colors based on the column and sort order
        updateHeaderColor(columnIndex, dataType);
        updateStatusTextColors(); // Update status text colors in the rows
    }

    // Function to update header color based on sorting
    function updateHeaderColor(columnIndex, dataType) {
        const headers = document.querySelectorAll('thead th');

        // Reset all header text colors to default (#272525)
        headers.forEach(header => header.style.color = '#272525');

        // Name column (index 1)
        if (columnIndex === 1) {
            headers[columnIndex].style.color = sortOrder === 'asc' ? '#C0392B' : '#272525' ;  // #4E4E4E for ascending, #C0392B for descending
        }

        // Status column (index 3) - Green if sorting for "Online" first, Red for "Offline" first
        else if (columnIndex === 3) {
            const firstStatus = document.querySelector("#user-table-body td:nth-child(4)").innerText;
            if (firstStatus === "Online") {
                headers[columnIndex].style.color = '#2ECC71';  // Sorted by Online
            } else if (firstStatus === "Offline") {
                headers[columnIndex].style.color = '#C0392B';  // Sorted by Offline
            }
        }

        // User Since column (index 4)
        else if (columnIndex === 4 && dataType === 'date') {
            headers[columnIndex].style.color = sortOrder === 'asc' ? '#B3B3B3' : '#272525';  // #B3B3B3 for ascending, #C0392B for descending
        }
    }

    // Function to update the color of the status text in each row based on the value ("Online" or "Offline")
    function updateStatusTextColors() {
        const statusCells = document.querySelectorAll("#user-table-body td:nth-child(4)");
        statusCells.forEach(cell => {
            if (cell.innerText === "Online") {
                cell.style.color = '#2ECC71'; // Online turns green
            } else if (cell.innerText === "Offline") {
                cell.style.color = '#C0392B'; // Offline turns red
            }
        });
    }

    // Trigger initial display
    window.onload = function() {
        displayTablePage(currentPage);
    };

    // Search Functionality
    function searchTable() {
        const input = document.getElementById('search-input').value.toUpperCase();
        const table = document.getElementById("user-table-body");
        const tr = table.getElementsByTagName("tr");

        for (let i = 0; i < tr.length; i++) {
            const tdName = tr[i].getElementsByTagName("td")[1]; // Name column
            const tdEmail = tr[i].getElementsByTagName("td")[2]; // Email column
            const tdPhone = tr[i].getElementsByTagName("td")[0]; // Phone column

            if (tdName || tdEmail || tdPhone) {
                const nameValue = tdName.textContent || tdName.innerText;
                const emailValue = tdEmail.textContent || tdEmail.innerText;
                const phoneValue = tdPhone.textContent || tdPhone.innerText;

                if (nameValue.toUpperCase().indexOf(input) > -1 || 
                    emailValue.toUpperCase().indexOf(input) > -1 || 
                    phoneValue.toUpperCase().indexOf(input) > -1) {
                    tr[i].style.display = "";
                } else {
                    tr[i].style.display = "none";
                }
            }
        }
    }
</script>



</head>
<body>
    <div class="user-side_container">
        <header class="navbar">
            <div class="logo">
                <img src="icons/logo.png" alt="Heavy Metals Logo">
                <p>Heavy Metals</p>
            </div>
            
            <nav>
                <ul>
                    <li><a href="admin_chart.php" class="add_exercise1">Dashboard</a></li>
                    <li><a href="admin_user.php" class="edit_users">Edit Users</a></li>
                    <li><a href="admin_add_exercise.php" class="add_exercise1">Add Exercise</a></li>
                    <li><a href="logout.php" class="logout">Logout</a></li>
                </ul>
            </nav>
        </header>

        <div class="table-container">
            <div class="acc-container">
                <h2 id="accounts">ACCOUNTS</h2>
                    <!-- Rows per page selection -->
                <div class="rowsPerPage-container">
                    <label  id="rowsPerPageTxt" for="rowsPerPage">Show:</label>
                        <select id="rowsPerPage" onchange="changeRowsPerPage()">
                            <option value="5">5 per page</option>
                            <option value="10" selected>10 per page</option> <!-- Default -->
                            <option value="20">20 per page</option>
                            <option value="all">Show all</option>
                        </select>
                </div>
                <input type="text" id="search-input" placeholder="Search by name, email, or phone..." onkeyup="searchTable()">
            
            
            </div>

          
            
            
            <table class="accounts-table">
                <thead>
                    <tr>
                        <th id="phoneNumber" onclick="sortTable(0, 'text')">Phone Number</th>
                        <th id="Name" onclick="sortTable(1, 'text')">Name</th>
                        <th id="email" onclick="sortTable(2, 'text')">Email</th>
                        <th id="status" onclick="sortTable(3, 'text')">Status</th>
                        <th id="userSince" onclick="sortTable(4, 'date')">User Since</th>
                        <th></th>
                        
                    </tr>
                </thead>
                <tbody id="user-table-body">
                    <?php
                    if ($result->num_rows > 0) {
                        while ($row = $result->fetch_assoc()) {
                            // Format the created_at date into the desired format (e.g., January 1, 2024)
                            $formatted_date = date('F j, Y', strtotime($row['created_at']));

                            // Determine the user's status based on session_token (online or offline)
                            $status = !empty($row['session_token']) ? "Online" : "Offline";

                            echo "<tr data-created-at='{$row['created_at']}'>
                                    <td>" . $row["phone_number"] . "</td>
                                    <td>" . $row["name"] . "</td>
                                    <td>" . $row["email"] . "</td>
                                    <td>" . $status . "</td>
                                    <td>" . $formatted_date . "</td>
                                
                                    <td>
                                        <form action='delete_user.php' method='POST' onsubmit='return confirmDelete()'>
                                            <input type='hidden' name='user_id' value='" . $row["user_id"] . "' />
                                            <button type='submit' class='delete-btn'>Delete</button>
                                        </form>
                                    </td>
                                  </tr>";
                        }
                    } else {
                        echo "<tr><td colspan='6'>No records found</td></tr>";
                    }
                    ?>
                </tbody>
            </table>
            
            <!-- Pagination Controls -->
            <div id="pagination-controls"></div>
        </div>
    </div>
</body>
</html>

<?php
// Close the connection
$conn->close();
?>
