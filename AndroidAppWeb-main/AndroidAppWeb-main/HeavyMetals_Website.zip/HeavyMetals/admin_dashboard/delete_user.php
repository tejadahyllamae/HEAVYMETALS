<?php
// Include the database connection file
require '../database.php';

// Check if the request method is POST and if the 'user_id' is set
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['user_id'])) {
    // Get the user_id from the POST request
    $user_id = $_POST['user_id'];

    // Debugging: Output user_id to check if it's passed correctly
    if(empty($user_id)) {
        echo "User ID is missing.";
        exit;
    }

    // Prepare the SQL statement to delete the user from the database
    $sql = "DELETE FROM user_register WHERE user_id = ?"; // Ensure the table and column names are correct

    // Use a prepared statement to prevent SQL injection
    if ($stmt = $conn->prepare($sql)) {
        // Bind the 'user_id' as an integer
        $stmt->bind_param("i", $user_id);

        // Execute the statement
        if ($stmt->execute()) {
            // Check if any row was affected (user deleted)
            if ($stmt->affected_rows > 0) {
                echo "User deleted successfully.";
            } else {
                echo "Error: User not found.";
            }
        } else {
            // Handle any errors during execution
            echo "Error executing query: " . $stmt->error;
        }

        // Close the statement
        $stmt->close();
    } else {
        // Handle errors preparing the statement
        echo "Error preparing query: " . $conn->error;
    }

} else {
    // If the request method isn't POST or 'user_id' isn't set
    echo "Invalid request.";
}

// Close the database connection
$conn->close();

// Redirect back to the admin user page after deletion
// Only redirect if no errors occurred
if(!headers_sent()) {
    header("Location: admin_user.php");
    exit;
}

?>
