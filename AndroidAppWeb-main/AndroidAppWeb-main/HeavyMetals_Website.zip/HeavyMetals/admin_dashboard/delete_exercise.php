<?php
session_start();

// Check if admin is logged in
if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
    header("Location: admin_login.php");
    exit;
}

require '../database.php';

// Ensure the request is a POST request (for password confirmation)
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $exercise_id = $_POST['id'] ?? '';  // Retrieve the exercise ID from POST data
    $password = $_POST['password'] ?? '';  // Retrieve the password from POST data

    if (!empty($exercise_id) && !empty($password)) {
        // Hardcoded password check (replace with a more secure method in production)
        if ($password === 'password') {
            // Proceed with deletion since the password is correct
            $stmt = $conn->prepare("DELETE FROM exercises_list WHERE id = ?");
            $stmt->bind_param("i", $exercise_id);

            if ($stmt->execute()) {
                // Return a success response to the JavaScript and redirect
                echo json_encode(['success' => true]);
            } else {
                echo json_encode(['success' => false, 'message' => 'Failed to delete exercise.']);
            }

            $stmt->close();
        } else {
            // Incorrect password
            echo json_encode(['success' => false, 'message' => 'Incorrect password.']);
        }
    } else {
        // Handle missing ID or password
        echo json_encode(['success' => false, 'message' => 'Exercise ID or password missing.']);
    }

    $conn->close();
} else {
    // If the request is not POST, redirect to avoid accidental deletions
    header("Location: admin_add_exercise.php");
    exit;
}
