<?php
include '../database.php'; // Database connection

// Check if request method is POST
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Retrieve input data
    $email = isset($_POST['email']) ? $_POST['email'] : '';
    $first_name = isset($_POST['first_name']) ? $_POST['first_name'] : '';
    $last_name = isset($_POST['last_name']) ? $_POST['last_name'] : '';
    $date_of_birth = isset($_POST['date_of_birth']) ? $_POST['date_of_birth'] : '';
    $profile_picture = isset($_FILES['profile_picture']) ? $_FILES['profile_picture'] : null;

    // Check for empty fields
    if (empty($email) || empty($first_name) || empty($last_name) || empty($date_of_birth)) {
        echo json_encode(['success' => false, 'message' => 'Please fill all fields.']);
        exit();
    }

    // Query to check if the email exists
    $query = "SELECT id FROM users WHERE email = ?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $result = $stmt->get_result();

    // If user exists
    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
        $user_id = $row['id'];

        // Prepare to upload profile picture if provided
        $profile_picture_path = '';
        if ($profile_picture) {
            $target_dir = "uploads/";
            $profile_picture_path = $target_dir . basename($profile_picture["name"]);
            move_uploaded_file($profile_picture["tmp_name"], $profile_picture_path);
        }

        // Insert or update the profile information
        $update_query = "INSERT INTO profiles (user_id, first_name, last_name, date_of_birth, profile_picture)
                        VALUES (?, ?, ?, ?, ?)
                        ON DUPLICATE KEY UPDATE first_name = VALUES(first_name), last_name = VALUES(last_name), date_of_birth = VALUES(date_of_birth), profile_picture = VALUES(profile_picture)";
        
        $stmt = $conn->prepare($update_query);
        $stmt->bind_param("issss", $user_id, $first_name, $last_name, $date_of_birth, $profile_picture_path);
        
        if ($stmt->execute()) {
            echo json_encode(['success' => true, 'message' => 'Profile updated successfully.']);
        } else {
            echo json_encode(['success' => false, 'message' => 'Error updating profile.']);
        }
    } else {
        echo json_encode(['success' => false, 'message' => 'User not found.']);
    }
    
    $stmt->close();
} else {
    echo json_encode(['success' => false, 'message' => 'Invalid request method.']);
}

$conn->close();
?>
