<?php
header('Content-Type: application/json');

// Set the timezone to Philippines
date_default_timezone_set('Asia/Manila');

// Get the current date and time
$currentDateTime = new DateTime();
$formattedDateTime = $currentDateTime->format('m/d/Y h:i A'); // Format: MM/DD/YYYY HH:MM AM/PM

// Create a response array
$response = [
    'current_time' => $formattedDateTime,
];

// Return the JSON response
echo json_encode($response);
?>
