<?php
header('Content-Type: application/json');
require 'database.php'; // Include MySQLi connection

// Enable error reporting for debugging
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

// Get verification token from URL
$verification_token = $_GET['token'] ?? '';
$verification_link = "https://heavymetals.scarlet2.io/HeavyMetals/verify.html?token=" . urlencode($verification_token);

if (empty($verification_token)) {
    echo json_encode(["success" => 0, "message" => "Invalid verification token."]);
    exit;
}

// Verify the user
$stmt = $conn->prepare("SELECT user_id FROM user_register WHERE verification_token = ? AND is_verified = 0");
$stmt->bind_param("s", $verification_token);
$stmt->execute();
$stmt->store_result();

if ($stmt->num_rows === 0) {
    echo json_encode(["success" => 0, "message" => "Invalid or expired verification token."]);
    exit;
}

$stmt->fetch();

// Update user status to verified
$updateStmt = $conn->prepare("UPDATE user_register SET is_verified = 1, verification_token = NULL WHERE verification_token = ?");
$updateStmt->bind_param("s", $verification_token);
$updateStmt->execute();

if ($updateStmt->affected_rows > 0) {
    echo json_encode(["success" => 1, "message" => "Email verified successfully!"]);
} else {
    echo json_encode(["success" => 0, "message" => "Email verification failed."]);
}
?>
