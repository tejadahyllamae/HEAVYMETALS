<?php
require '../vendor/autoload.php';  // Load PHPMailer if needed for notifications
require '../database.php';         // Include MySQLi connection

$response = ['success' => 0, 'message' => ''];

$userId = $_POST['user_id'] ?? '';  // Get user_id from the request
$newPassword = $_POST['new_password'] ?? '';
$confirmPassword = $_POST['confirm_password'] ?? '';

// Input validation
if (empty($userId) || empty($newPassword) || empty($confirmPassword)) {
    $response['message'] = 'All fields are required.';
    echo json_encode($response);
    exit;
}

if ($newPassword !== $confirmPassword) {
    $response['message'] = 'Passwords do not match.';
    echo json_encode($response);
    exit;
}

if (strlen($newPassword) < 6) {
    $response['message'] = 'Password must be at least 6 characters long.';
    echo json_encode($response);
    exit;
}

// Hash the new password
$hashedPassword = password_hash($newPassword, PASSWORD_DEFAULT);

// Update password
$updateStmt = $conn->prepare("UPDATE user_register SET password = ? WHERE user_id = ?");
if (!$updateStmt) {
    $response['message'] = 'Failed to prepare SQL statement for password update.';
    echo json_encode($response);
    exit;
}

$updateStmt->bind_param("si", $hashedPassword, $userId);

if ($updateStmt->execute()) {
    $response['success'] = 1;
    $response['message'] = 'Your password has been updated successfully.';
} else {
    $response['message'] = 'Failed to update password. Please try again.';
}

$updateStmt->close();
echo json_encode($response);
?>
