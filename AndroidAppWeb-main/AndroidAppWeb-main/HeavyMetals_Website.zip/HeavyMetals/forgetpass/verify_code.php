<?php
require '../database.php';  // Include MySQLi connection

$response = ['success' => 0, 'message' => ''];

// Get the reset code and sanitize it
$resetCode = filter_var($_POST['reset_code'], FILTER_SANITIZE_STRING);

if (empty($resetCode)) {
    $response['message'] = 'Reset code is required.';
    echo json_encode($response);
    exit;
}

// Check if the reset code exists, is valid, and hasn't expired
$stmt = $conn->prepare("SELECT user_id, use_count, created_at FROM password_resets WHERE reset_token = ?");
if (!$stmt) {
    $response['message'] = 'Failed to prepare SQL statement.';
    echo json_encode($response);
    exit;
}

$stmt->bind_param("s", $resetCode);
$stmt->execute();
$stmt->store_result();

if ($stmt->num_rows == 0) {
    // Invalid reset code
    $response['message'] = 'Invalid reset code.';
    echo json_encode($response);
    exit;
}

$stmt->bind_result($userId, $useCount, $createdAt);
$stmt->fetch();
$stmt->close();

// Check if the token is older than 10 minutes
$currentTime = new DateTime();
$tokenCreationTime = new DateTime($createdAt);
$interval = $currentTime->diff($tokenCreationTime);
$minutesPassed = $interval->i;

if ($minutesPassed >= 10) {
    // Token has expired, so delete it
    $deleteStmt = $conn->prepare("DELETE FROM password_resets WHERE reset_token = ?");
    $deleteStmt->bind_param("s", $resetCode);
    $deleteStmt->execute();
    $deleteStmt->close();

    $response['message'] = 'Reset code has expired.';
    echo json_encode($response);
    exit;
}

// Check if the token has been used twice already
if ($useCount >= 2) {
    $response['message'] = 'Reset code has already been used twice.';
    echo json_encode($response);
    exit;
}

// Increment the use count in the database
$incrementStmt = $conn->prepare("UPDATE password_resets SET use_count = use_count + 1 WHERE reset_token = ?");
if (!$incrementStmt) {
    $response['message'] = 'Failed to prepare SQL statement for incrementing use count.';
    echo json_encode($response);
    exit;
}

$incrementStmt->bind_param("s", $resetCode);
$incrementStmt->execute();
$incrementStmt->close();

// If code is verified, allow the user to proceed to the password reset page
$response['success'] = 1;
$response['message'] = 'Code verified successfully. Please proceed to reset your password.';
$response['user_id'] = $userId;  // Optionally send back user_id to reference in the password reset process

echo json_encode($response);
?>