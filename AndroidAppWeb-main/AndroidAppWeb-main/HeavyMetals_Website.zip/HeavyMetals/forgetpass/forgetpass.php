<?php
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;
require '../vendor/autoload.php';  // Load PHPMailer
require '../database.php';         // Include MySQLi connection

$response = ['success' => 0, 'message' => ''];

// Get and sanitize the email input
$email = filter_var($_POST['email'], FILTER_SANITIZE_EMAIL);

if (!$email || !filter_var($email, FILTER_VALIDATE_EMAIL)) {
    $response['message'] = 'Invalid email address.';
    echo json_encode($response);
    exit;
}

// Check if the email exists in the user_register table
$stmt = $conn->prepare("SELECT user_id FROM user_register WHERE email = ?");
if (!$stmt) {
    $response['message'] = 'Failed to prepare SQL statement.';
    echo json_encode($response);
    exit;
}

$stmt->bind_param("s", $email);
$stmt->execute();
$stmt->store_result();

if ($stmt->num_rows == 0) {
    // No user found with this email
    $response['message'] = 'Email not found.';
    echo json_encode($response);
    exit;
}

$stmt->bind_result($userId);
$stmt->fetch();
$stmt->close();

// Function to generate a 5-character alphanumeric reset code
function generateResetCode($length = 5) {
    return substr(str_shuffle('0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ'), 0, $length);
}

// Generate a 5-character reset code
$resetToken = generateResetCode();

// Store the reset token in the password_resets table
$stmt = $conn->prepare("REPLACE INTO password_resets (user_id, reset_token) VALUES (?, ?)");
$stmt->bind_param("is", $userId, $resetToken);
$stmt->execute();

// Send the password reset email
try {
    $mail = new PHPMailer(true);
    $mail->isSMTP();
    $mail->Host = 'smtp.gmail.com';
    $mail->SMTPAuth = true;
    $mail->Username = 'heavymetalscebu@gmail.com'; 
    $mail->Password = 'ppwy zvfk rgfl jsod'; 
    $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
    $mail->Port = 587;

    $mail->setFrom('heavymetalscebu@gmail.com', 'Heavy Metals');
    $mail->addAddress($email);  // Send to the user's email

    // Create the password reset message with the 5-character reset code
    $mail->isHTML(true);
    $mail->Subject = 'Password Reset Request';
    $mail->Body = "Your password reset code is: <b>$resetToken</b>";

    $mail->send();
    $response['success'] = 1;
    $response['message'] = 'Password reset code has been sent to your email.';
} catch (Exception $e) {
    $response['message'] = 'Failed to send email. Error: ' . $mail->ErrorInfo;
}

echo json_encode($response);
?>
