<?php
// Enable error reporting for debugging (disable in production)
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

// Include database connection
require '../database.php'; // Ensure this path is correct and no errors are output here

// Set header to return JSON
header('Content-Type: application/json');

// Check if the request method is POST
if ($_SERVER["REQUEST_METHOD"] == "POST") {

    // Get the user_id and session_token from POST data
    $user_id = isset($_POST['user_id']) ? $_POST['user_id'] : null;
    $session_token = isset($_POST['session_token']) ? $_POST['session_token'] : null;

    // Check if user_id and session_token are provided
    if (empty($user_id) || empty($session_token)) {
        echo json_encode([
            "success" => false,
            "message" => "User ID and session token are required."
        ]);
        exit;
    }

    // (Optional) Token validation logic
    if (!validate_token($session_token)) {
        echo json_encode(["success" => false, "message" => "Invalid session token."]);
        exit;
    }

    // Check for database connection errors
    if ($conn->connect_error) {
        echo json_encode([
            "success" => false,
            "message" => "Database connection failed: " . $conn->connect_error
        ]);
        exit;
    }

    // Prepare the SQL statement to delete the user from the database
    $sql = "DELETE FROM user_register WHERE user_id = ?";
    
    if ($stmt = $conn->prepare($sql)) {
        $stmt->bind_param("i", $user_id); // Bind the user_id as an integer

        if ($stmt->execute()) {
            if ($stmt->affected_rows > 0) {
                echo json_encode([
                    "success" => true,
                    "message" => "User deleted successfully."
                ]);
            } else {
                echo json_encode([
                    "success" => false,
                    "message" => "User not found."
                ]);
            }
        } else {
            echo json_encode([
                "success" => false,
                "message" => "Error executing query: " . $stmt->error
            ]);
        }

        $stmt->close();
    } else {
        echo json_encode([
            "success" => false,
            "message" => "Error preparing query: " . $conn->error
        ]);
    }

} else {
    // If the request method isn't POST
    echo json_encode([
        "success" => false,
        "message" => "Invalid request method."
    ]);
}

// Close the database connection
$conn->close();

// Placeholder token validation function (implement your logic)
function validate_token($session_token) {
    // Add logic to validate session token, such as querying the database or checking against a static value
    return true; // For now, always return true
}
