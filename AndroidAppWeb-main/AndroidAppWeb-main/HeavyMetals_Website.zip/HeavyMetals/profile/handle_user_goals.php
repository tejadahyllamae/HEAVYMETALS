<?php
require '../database.php';

// Check if the POST request has been made
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Validate and sanitize user_id
    if (isset($_POST['user_id'])) {
        $user_id = filter_var($_POST['user_id'], FILTER_VALIDATE_INT);  // Validate that user_id is an integer
        $lose_weight = isset($_POST['lose_weight']) ? (int)$_POST['lose_weight'] : 0;
        $increase_strength = isset($_POST['increase_strength']) ? (int)$_POST['increase_strength'] : 0;
        $build_muscle = isset($_POST['build_muscle']) ? (int)$_POST['build_muscle'] : 0;
        $mobility = isset($_POST['mobility']) ? (int)$_POST['mobility'] : 0;
        $wellness_reduce_stress = isset($_POST['wellness_reduce_stress']) ? (int)$_POST['wellness_reduce_stress'] : 0;
        $fitness = isset($_POST['fitness']) ? (int)$_POST['fitness'] : 0;

        // Prepare and bind the SQL statement
        $stmt = $conn->prepare("INSERT INTO user_goals ( lose_weight, increase_strength, build_muscle, mobility, wellness_reduce_stress, fitness) 
                                VALUES ( ?, ?, ?, ?, ?, ?)");
        if (!$stmt) {
            echo json_encode(["status" => "error", "message" => "Database preparation failed: " . $conn->error]);
            exit;
        }
        $stmt->bind_param("iiiiii",  $lose_weight, $increase_strength, $build_muscle, $mobility, $wellness_reduce_stress, $fitness);

        // Execute the statement
        if ($stmt->execute()) {
            echo json_encode(["status" => "success", "message" => "Goals submitted successfully"]);
        } else {
            echo json_encode(["status" => "error", "message" => "Failed to submit goals: " . $stmt->error]);
        }

        // Close statement and connection
        $stmt->close();
        $conn->close();
    } else {
        echo json_encode(["status" => "error", "message" => "Invalid input data"]);
    }
} else {
    echo json_encode(["status" => "error", "message" => "Invalid request method"]);
}
?>
