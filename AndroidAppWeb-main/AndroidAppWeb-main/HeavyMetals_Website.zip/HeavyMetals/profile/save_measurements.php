<?php
require '../database.php';

// Get the raw POST data and log it for debugging
$raw_data = file_get_contents('php://input');
file_put_contents("debug.log", "Raw Data: " . $raw_data . PHP_EOL, FILE_APPEND);

// Decode the JSON data
$data = json_decode($raw_data, true);

// Log the decoded data
file_put_contents("debug.log", "Decoded Data: " . print_r($data, true) . PHP_EOL, FILE_APPEND);

// Check if JSON decoding failed
if (json_last_error() !== JSON_ERROR_NONE) {
    echo "JSON decode error: " . json_last_error_msg();
    exit;
}

// Extract values from the decoded JSON data
$user_id = isset($data['user_id']) ? $data['user_id'] : null;
$gender = isset($data['gender']) ? $data['gender'] : null;
$body_weight = isset($data['body_weight']) ? $data['body_weight'] : null;
$height = isset($data['height']) ? $data['height'] : null;
$chest = isset($data['chest']) ? $data['chest'] : null;
$shoulder = isset($data['shoulder']) ? $data['shoulder'] : null;
$waist = isset($data['waist']) ? $data['waist'] : null;
$hips = isset($data['hips']) ? $data['hips'] : null;
$left_bicep = isset($data['left_bicep']) ? $data['left_bicep'] : null;
$right_bicep = isset($data['right_bicep']) ? $data['right_bicep'] : null;
$left_forearm = isset($data['left_forearm']) ? $data['left_forearm'] : null;
$right_forearm = isset($data['right_forearm']) ? $data['right_forearm'] : null;
$left_calf = isset($data['left_calf']) ? $data['left_calf'] : null;
$right_calf = isset($data['right_calf']) ? $data['right_calf'] : null;

// Debugging: Print the required values before checking them
echo "user_id: $user_id, gender: $gender, body_weight: $body_weight, height: $height<br>";
file_put_contents("debug.log", "Extracted Values - user_id: $user_id, gender: $gender, body_weight: $body_weight, height: $height" . PHP_EOL, FILE_APPEND);

// Check if any required data is missing
if (!$user_id || !$gender || !$body_weight || !$height) {
    echo "Missing required data";
    exit;
}

// Check if measurements already exist for the user
$sql_check = "SELECT * FROM measurements WHERE user_id = '$user_id'";
$result = $conn->query($sql_check);

if ($result->num_rows > 0) {
    // If measurements already exist, update them
    $sql_update = "UPDATE measurements SET 
        gender = '$gender',
        body_weight = '$body_weight',
        height = '$height',
        chest = '$chest',
        shoulder = '$shoulder',
        waist = '$waist',
        hips = '$hips',
        left_bicep = '$left_bicep',
        right_bicep = '$right_bicep',
        left_forearm = '$left_forearm',
        right_forearm = '$right_forearm',
        left_calf = '$left_calf',
        right_calf = '$right_calf'
        WHERE user_id = '$user_id'";

    if ($conn->query($sql_update) === TRUE) {
        echo "Measurements updated successfully!";
    } else {
        echo "Error updating measurements: " . $conn->error;
    }
} else {
    // If no measurements exist, insert a new row
    $sql_insert = "INSERT INTO measurements (user_id, gender, body_weight, height, chest, shoulder, waist, hips, left_bicep, right_bicep, left_forearm, right_forearm, left_calf, right_calf)
        VALUES ('$user_id', '$gender', '$body_weight', '$height', '$chest', '$shoulder', '$waist', '$hips', '$left_bicep', '$right_bicep', '$left_forearm', '$right_forearm', '$left_calf', '$right_calf')";

    if ($conn->query($sql_insert) === TRUE) {
        echo "Measurements saved successfully!";
    } else {
        echo "Error saving measurements: " . $conn->error;
    }
}

// Close the connection
$conn->close();
?>
