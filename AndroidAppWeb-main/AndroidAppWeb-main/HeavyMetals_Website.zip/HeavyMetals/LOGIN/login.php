<?php
session_start();  // Start the session

require '../database.php';

// Get the login data
$email = $_POST['email'];
$password = $_POST['password'];

// Validate the user's credentials
$authQuery = "SELECT user_id, password FROM user_register WHERE email = ?";
$stmt = $conn->prepare($authQuery);
$stmt->bind_param("s", $email);
$stmt->execute();
$stmt->store_result();

if ($stmt->num_rows > 0) {
    $stmt->bind_result($user_id, $hashed_password);
    $stmt->fetch();

    // Verify the password
    if (password_verify($password, $hashed_password)) {
        // Store user ID in session
        $_SESSION['user_id'] = $user_id;
        $_SESSION['email'] = $email;

        echo "Login successful!";
    } else {
        echo "Invalid password.";
    }
} else {
    echo "Invalid email.";
}

// Close the connection
$stmt->close();
$conn->close();
?>
