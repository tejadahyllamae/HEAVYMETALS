<?php
header('Content-Type: application/json');
require 'database.php'; // Include MySQLi connection

// Enable error reporting for debugging
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

// Get POST data
$email = $_POST['email'] ?? '';
$password = $_POST['password'] ?? '';

// Input validation
if (empty($email) || empty($password)) {
    echo json_encode(["success" => 0, "message" => "Email and Password are required."]);
    exit;
}

// Prepare and execute SQL query to get password hash, verification status, and first_login for the email
$stmt = $conn->prepare("SELECT user_id, password, is_verified, first_login FROM user_register WHERE email = ?");
$stmt->bind_param("s", $email);
$stmt->execute();
$stmt->store_result();
$stmt->bind_result($user_id, $password_hash, $is_verified, $first_login);
$stmt->fetch();

if ($stmt->num_rows === 0) {
    echo json_encode(["success" => 0, "message" => "Invalid email or password."]);
    exit;
}

// Check if the user is verified
if ($is_verified == 0) { // Assuming 0 means not verified
    echo json_encode(["success" => 0, "message" => "Account not verified. Please check your email for the verification link."]);
    exit;
}

// Verify password
if (!password_verify($password, $password_hash)) {
    echo json_encode(["success" => 0, "message" => "Incorrect password."]);
    exit;
}

// Generate a token (this could be a simple token or JWT)
$token = bin2hex(random_bytes(16));

// Store the session token in the database
$updateTokenStmt = $conn->prepare("UPDATE user_register SET session_token = ? WHERE user_id = ?");
$updateTokenStmt->bind_param("si", $token, $user_id);

if ($updateTokenStmt->execute()) {
    // Check if it's the first login
    if ($first_login == 1) {
        // If it's the first login, update first_login to 0
        $updateFirstLoginStmt = $conn->prepare("UPDATE user_register SET first_login = 0 WHERE user_id = ?");
        $updateFirstLoginStmt->bind_param("i", $user_id);
        $updateFirstLoginStmt->execute();
        $updateFirstLoginStmt->close();
    }

    // Return success, token, user_id, and first_login status in the response
    echo json_encode([
        "success" => 1, 
        "token" => $token, 
        "user_id" => $user_id, 
        "first_login" => $first_login // Return this so the client app can handle the first login flow
    ]);
} else {
    echo json_encode(["success" => 0, "message" => "Failed to update session token."]);
}

$updateTokenStmt->close();
$stmt->close();
$conn->close();
?>
